# 미국 팩터 정보 시점 감사

DeepFund가 분리한 정보 이용 시점과 거래 시점을 월 단위 결정적 팩터 원장에 적용하였다. 원장에는 거래월, 신호월, 종목, CIK, 팩터, 사용한 공시 접수번호와 정보 이용 가능일이 있다. 가치 팩터의 시가총액 분모에 사용한 주식 수도 별도 공시 접수번호에 대응한다.

감사는 거래월이 신호월 뒤에 있는지 먼저 확인한다. 가치·수익성·저발생액은 CIK와 접수번호로 SEC 입력을 대조하고, 원장에 기록한 이용 가능일과 SEC 처리 파일의 날짜가 일치하며 신호월의 시작 전에 이용 가능해야 통과한다. 가치는 주식 수 원본의 이용 가능일도 별도로 검사한다. 원장의 모멘텀 행에는 당시 가격 판본이나 관측 시각 식별자가 없으므로 가격 출처 미검증으로 기록한다.

| EC2 원장 행 | 건수 | 범위 |
|---|---:|---|
| 공시 이용 순서 확인 | 7,389 | 가치·수익성·저발생액 |
| 가격 출처 미검증 | 2,463 | 모멘텀 |
| 날짜 순서 또는 출처 불일치 | 0 | 위 계약으로 확인 가능한 기록 |
| 전체 | 9,852 | 미국 종목 팩터 선택 원장 |

이 검사는 월 단위로 보관된 SEC 자료와 원장 사이의 일관성을 검증한다. 실제 장중 체결 시각, 당시 가격 파일, LLM 학습·출시 시점, 전략의 수익성은 별도 검증 대상이다.

```bash
study=/var/lib/fintos-portfolio/2026-11-28
python3 scripts/audit_factor_information_timing.py \
  --selections "$study/us-factor-extension/verified/us_factor_selections.csv" \
  --sec-filings "$study/us-pit/outputs/finance_us.csv" \
  --out "$study/us-factor-extension/information-timing"
```

EC2 SSM 실행 `842852c1-19a4-4d35-9a3e-fa6844959faa`에서 감사 결과 CSV와 요약 JSON을 생성했다. [DeepFund 공식 프로시딩](https://proceedings.nips.cc/paper_files/paper/2025/hash/f37b0e09b90e9a6833aacf5768362b54-Abstract-Datasets_and_Benchmarks_Track.html)
