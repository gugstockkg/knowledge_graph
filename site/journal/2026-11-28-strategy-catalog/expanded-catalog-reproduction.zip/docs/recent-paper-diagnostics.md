# 원문 기반 팩터 진단

## JA-RoF-078. Fama–French 자료 판본

2024년 12월에 마감된 공식 구판 FIZ와 기존 FINTOS 실험에 보관한 CIZ를 비교했다. 두 판본의 입력 날짜를 일치시켜 2021년 12월~2024년 12월의 공통 37개월만 평가했다. 네 스타일 요인의 동일 비중과 기존 부호 타이밍, 시장 기준을 각각 같은 규칙으로 재계산했다. 부호 타이밍은 의사결정 월 직전 한 달을 건너뛴 12개월의 누적 요인 초과수익으로 방향을 정했다. FIZ는 월말 배당 재투자 방식을, CIZ는 배당락일 재투자를 포함하는 일별 수익 복리 방식을 사용한다. 두 파일에는 다른 데이터 갱신도 들어갈 수 있으므로 관측 차이를 한 가지 원인으로 귀속하지 않았다. [논문](https://doi.org/10.1093/rof/rfag002) · [구판 자료](https://mba.tuck.dartmouth.edu/pages/faculty/Ken.french/data_library_202412_archive.html) · [현행 자료](https://mba.tuck.dartmouth.edu/pages/faculty/Ken.french/data_library.html)

| 24개월 전략 · 공통 14개 평가창 | FIZ 수익률 중앙값 | CIZ 수익률 중앙값 | 같은 창의 CIZ−FIZ 차이 중앙값 |
|---|---:|---:|---:|
| 시장 | +34.13% | +34.49% | +0.38%p |
| 정적 동일 비중 | +6.59% | +6.32% | −0.26%p |
| 부호 타이밍 | +4.87% | +5.04% | +0.21%p |

월별 요인 부호 148개에서는 바뀐 경우가 없었다. HML의 월별 수익률 최대 절대 차이는 0.43%p였다. 12개월 창은 26개다. 이는 동일 기간의 팩터 판본 점검으로 기존 전략표에서 평가창을 연장하거나 별도의 전략으로 셀 필요가 없다. [기간별 요약](../results/french_vintage_summary.csv) · [요인별 차이](../results/french_vintage_factor_deltas.csv) · [원본 해시](../results/french_vintage_manifest.csv)

## FC15. 설계 경로 간 결과 의존성

동일한 2021년 12월~2026년 9월 자료 58개월에서 여덟 가지 부호 타이밍 조건을 사전에 고정했다. 선택지는 지연 신호 6·12개월, 정적 동일 비중에서 목표 부호까지의 이동 폭 50%·100%, 비중 변경 비용 0·10bp다. 각 조건에서 정적 동일 비중 대비 월별 순초과수익을 계산했다. 사전에 계산한 월별 순초과수익의 인접성은 원형 이동 블록 부트스트랩으로 보존했다. 공통 블록으로 경로 전체를 표본 추출한 조건과 같은 길이의 블록을 각 경로에서 별도로 추출한 조건의 결과를 1,000번 비교했다.

| 6개월 블록 · 1,000회 | 경로 쌍의 평균 절대 상관 | 경로 평균 월별 초과수익 추정값의 표준편차 |
|---|---:|---:|
| 같은 위상의 블록을 경로 전체에 적용 | 0.731 | 0.134%p |
| 경로마다 별도로 블록 추출 | 0.027 | 0.059%p |

3개월·12개월 블록에서도 공통 표본 추출 조건의 경로 사이 상관과 추정 변동성이 더 컸다. 경로별 표본 추출은 같은 월을 공유하는 실제 후보 전략 사이의 의존성을 해소한 검정으로 해석할 수 없다. 원문은 종목 패널을 다시 샘플링한 뒤 롱쇼트 신호를 재구축한다. 여기서는 준비된 월 수익률과 가중치 규칙을 이용해 같은 표본을 공유하는 비교 조건을 독립 실험처럼 셀 때의 영향을 살폈다. [블록 길이별 요약](../results/factor_design_bootstrap.csv) · [여덟 가지 조건](../results/factor_design_paths.csv)

## EC2 재현

```bash
study=/var/lib/fintos-portfolio/2026-11-28/factors-pit
mkdir -p "$study/french-vintage-audit/raw"
cp "$study/public-followup/raw/F-F_Research_Data_5_Factors_2x3_CSV.zip" \
  "$study/french-vintage-audit/raw/ciz-F-F_Research_Data_5_Factors_2x3_CSV.zip"
python3 scripts/compare_french_vintages.py \
  --raw "$study/french-vintage-audit/raw" --out "$study/french-vintage-audit"
python3 scripts/audit_factor_design_paths.py \
  --raw "$study/public-followup/raw" --out "$study/factor-design-audit"
```

실행 ID는 `f0817b6b-8bfa-4cd1-b4e4-f2f9a4d6cc41`와 `84b536d3-3557-45be-9c02-b4849d7a9899`다.
