"""Run literature-inspired, long-only variants over the archived FINTOS universe."""
import argparse
import bisect
import csv
import hashlib
import json
import math
import statistics
from collections import Counter, defaultdict
from pathlib import Path

import portfolio_engine as engine

BUILTINS = ('hold', 'rebalance', 'threshold', 'relative', 'trend', 'half_trend',
            'relative_half_trend', 'exit', 'partial', 'stop_loss')
FIVE_START = '2021-11-26'
PERIODS = {'all': ('2016', '2027'), 'five_year': (FIVE_START, '2027'),
           'previous': ('2016', FIVE_START), '2016-17': ('2016', '2018'),
           '2018-19': ('2018', '2020'), '2020-21': ('2020', '2022'),
           '2022-23': ('2022', '2024'), '2024+': ('2024', '2027')}


def monthly_book(study, portfolio):
    adjusted = {s: engine.series({d: row[2] for d, row in study.data[s][0].items()})
                for s in engine.ASSETS}
    rules = defaultdict(dict)

    def market_weights(us, kr):
        if portfolio == 'etf':
            return {engine.US[0]: us, engine.KR[0]: kr}
        return {engine.US[0]: us * .8, engine.KR[0]: kr * (2 / 3),
                **{s: us * .2 / 3 for s in engine.US[1:]},
                **{s: kr / 9 for s in engine.KR[1:]}}

    def returns(symbol, day, window):
        dates, values = adjusted[symbol]
        end = bisect.bisect_right(dates, day)
        days = dates[max(0, end - window - 1):end]
        if symbol in engine.US:
            days = [d for d in days if d > study.fx[0][0]]
        levels = [values[d] * (engine.prior(study.fx, d, strict=True)
                                if symbol in engine.US else 1.) for d in days]
        return [b / a - 1 for a, b in zip(levels, levels[1:])]

    for day in study.months.values():
        fixed = market_weights(.5, .3)
        rules['equal_market'][day] = market_weights(.4, .4)
        us, kr = (returns(s, day, 63) for s in (engine.US[0], engine.KR[0]))
        if min(len(us), len(kr)) >= 50:
            su, sk = max(.0001, statistics.stdev(us)), max(.0001, statistics.stdev(kr))
            risk_w = sk / (su + sk)
            # Estimate covariance on local-session returns matched by date.
            returns_by_date = []
            for symbol in (engine.US[0], engine.KR[0]):
                ds = adjusted[symbol][0]
                end = bisect.bisect_right(ds, day)
                returns_by_date.append(dict(zip(ds[end-len(us if symbol == engine.US[0] else kr):end],
                                                us if symbol == engine.US[0] else kr)))
            dates = sorted(returns_by_date[0].keys() & returns_by_date[1].keys())
            u, k = ([r[d] for d in dates] for r in returns_by_date)
            if len(dates) < 30:
                u, k = us, kr
            mean_u, mean_k = statistics.mean(u), statistics.mean(k)
            cov = (sum((x-mean_u)*(y-mean_k) for x,y in zip(u,k)) / (len(u)-1)
                   if len(dates) >= 30 else 0.)
            var_u, var_k = statistics.variance(u), statistics.variance(k)
            min_var = lambda c: min(.8, max(.2, (var_k - c) / max(1e-12, var_u + var_k - 2*c)))
            for name, w in [('risk_parity', risk_w), ('min_variance', min_var(cov)),
                            ('shrink_min_variance', min_var(cov * .5))]:
                rules[name][day] = market_weights(.8*w, .8*(1-w))
            vol = statistics.stdev([.5*x + .3*y for x, y in zip(u, k)]) * math.sqrt(252)
            scale = min(1., .12 / max(vol, .0001))
            rules['vol_target'][day] = market_weights(.5*scale, .3*scale)
        else:
            for name in ('risk_parity','min_variance','shrink_min_variance','vol_target'):
                rules[name][day] = fixed

        past = engine.month_end(engine.month_shift(day, -12))
        recent = engine.month_end(engine.month_shift(day, -1))
        trend_sizes = []
        for symbol, weight in ((engine.US[0], .5), (engine.KR[0], .3)):
            history = adjusted[symbol]
            trend_sizes.append(weight if past >= history[0][0] and
                               engine.prior(history, recent) > engine.prior(history, past) else 0.)
        rules['absolute_momentum'][day] = market_weights(*trend_sizes)

        if portfolio == 'mixed':
            for name in ('stock_momentum', 'stock_reversal'):
                weights = {engine.US[0]: .4, engine.KR[0]: .2}
                for market, symbols in [('US', engine.US[1:]), ('KR', engine.KR[1:])]:
                    cohort = symbols
                    if past >= max(adjusted[s][0][0] for s in symbols):
                        if name == 'stock_momentum':
                            score = lambda s: (engine.prior(adjusted[s], recent)
                                               / engine.prior(adjusted[s], past))
                            cohort = sorted(symbols, key=score, reverse=True)[:2]
                        else:
                            score = lambda s: (engine.prior(adjusted[s], day)
                                               / engine.prior(adjusted[s], recent))
                            cohort = sorted(symbols, key=score)[:2]
                    weights.update({s: .1/len(cohort) if s in cohort else 0. for s in symbols})
                rules[name][day] = weights
    return dict(rules)


def summarize(results):
    holds = {(r['cost_case'], r['portfolio'], r['start'], r['months']): r for r in results
             if r['strategy'] == 'hold'}
    groups = defaultdict(list)
    for r in results:
        benchmark = holds[r['cost_case'], r['portfolio'], r['start'], r['months']]
        r['paired_vs_hold'] = r['net'] - benchmark['net']
        labels = [p for p,(a,b) in PERIODS.items() if a <= r['start'] < b]
        common_hold = holds[r['cost_case'], 'etf', r['start'], r['months']]['net']
        labels.append('up' if common_hold >= .1 else 'down' if common_hold < 0 else 'middle')
        for label in labels:
            groups[label,r['cost_case'],r['portfolio'],r['months'],r['strategy']].append(r)
    out = []
    for (period,cost,portfolio,months,strategy), rows in sorted(groups.items()):
        net = [r['net'] for r in rows]
        delta = [r['paired_vs_hold'] for r in rows]
        out.append(dict(period=period, cost_case=cost, portfolio=portfolio, months=months,
                        strategy=strategy, n=len(rows), median_net=statistics.median(net),
                        median_drawdown=statistics.median(r['max_drawdown'] for r in rows),
                        median_paired=statistics.median(delta), wins=sum(x > 1e-10 for x in delta),
                        targets=sum(r['target'] for r in rows), worst_net=min(net),
                        total_fills=sum(r['trades'] for r in rows)))
    return out


def unavailable_maturities(study, last):
    missing = {}
    for deadline in study.months.values():
        if (deadline.year, deadline.month) >= (last.year, last.month):
            continue
        for assets, market_reference in ((engine.US, 'SPY'), (engine.KR, '005930.KS')):
            dates = study.closes[market_reference][0]
            i = bisect.bisect_right(dates, deadline) - 1
            if i < 0:
                continue
            market_close = dates[i]
            failures = [s for s in assets if market_close not in study.data[s][0]]
            if failures:
                missing.setdefault(deadline, []).extend(
                    dict(deadline=str(deadline), symbol=s, expected_close=str(market_close))
                    for s in failures)
    return missing


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--raw', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--end', type=engine.iso, default=engine.iso('2026-11-26'))
    parser.add_argument('--start', type=engine.iso, default=engine.iso('2016-01-01'))
    parser.add_argument('--cost-multipliers', type=float, nargs='+', default=[1, 2])
    a = parser.parse_args()
    cases = {f'{c:g}x' for c in a.cost_multipliers}
    if any(not math.isfinite(c) or c < 0 for c in a.cost_multipliers) or len(cases) != len(a.cost_multipliers):
        parser.error('cost multipliers must be distinct nonnegative numbers')
    a.raw.mkdir(parents=True, exist_ok=True)
    a.out.mkdir(parents=True, exist_ok=True)
    data = {s: engine.fetch(s, a.raw, engine.month_shift(a.start,-11), a.end)
            for s in (*engine.ASSETS, engine.FX)}
    engine.dump_csv(a.out/'data_manifest.csv', [r[3] for r in data.values()])
    study = engine.Study(data)
    books = {p: monthly_book(study,p) for p in ('etf','mixed')}
    last = min(max(x[0]) for x in data.values())
    unavailable = unavailable_maturities(study, last)
    engine.dump_csv(a.out/'excluded_maturities.csv', [r for group in unavailable.values() for r in group])
    results = []
    for multiplier in a.cost_multipliers:
        cost_case = f'{multiplier:g}x'
        study.transaction_cost, study.fx_cost = engine.COST*multiplier, engine.FX_COST*multiplier
        with (a.out/f'orders_{cost_case}.csv').open('w',newline='') as f:
            ledger=csv.writer(f)
            ledger.writerow(('portfolio','strategy','start','end','decision_date','trade_date',
                             'symbol','side','reason','shares_signed','local_price','fx_krw',
                             'cost_krw','cash_krw','holdings_asof','holdings_filing'))
            for portfolio, book in books.items():
                study.research_rules = book
                for start in study.months.values():
                    if start < a.start:
                        continue
                    for months in (12,24):
                        month = engine.month_shift(start,months)
                        deadline = study.months.get((month.year,month.month))
                        if deadline is None or deadline in unavailable or (month.year,month.month) >= (last.year,last.month):
                            continue
                        for strategy in (*BUILTINS,*book):
                            row=study.run(start,deadline,portfolio,strategy,ledger)
                            row.update(months=months,cost_case=cost_case)
                            results.append(row)
        print(cost_case,len(results),flush=True)
    assert results
    summary = summarize(results)
    engine.dump_csv(a.out/'cohorts.csv',results)
    engine.dump_csv(a.out/'summary.csv',summary)
    (a.out/'run.json').write_text(json.dumps(dict(start=str(a.start),last=str(last),
        cohorts=len(results), excluded_maturities=len(unavailable), strategy_counts={p:len(BUILTINS)+len(book) for p,book in books.items()},
        code_hash=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()),indent=2)+'\n')


if __name__=='__main__':
    main()
