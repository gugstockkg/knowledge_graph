"""Check account-level order replay boundaries and archived input identities."""
import argparse
import csv
import hashlib
import json
from collections import Counter
from pathlib import Path


def read(path):
    with path.open(newline='',encoding='utf-8-sig') as handle:
        yield from csv.DictReader(handle)


def key(row):
    return tuple(row[k] for k in ('cost_case','portfolio','strategy','start','end'))


def replay(path):
    ledger = {}
    account_count = {}
    for row in read(path/'cohorts.csv'):
        k=key(row)
        if k in ledger:
            raise ValueError(f'Duplicate account {k}')
        ledger[k]=row
    counts=Counter()
    for row in read(path/'orders.csv'):
        k=key(row)
        date=row['trade_date']
        if (k not in ledger or not row['decision_date'] <= date <= row['end']
                or row['reason'] != 'scheduled_deadline_close' and row['decision_date'] == date):
            raise ValueError(f'Invalid trading chronology {k} {date}')
        signed=float(row['shares_signed'])
        cash=float(row['cash_krw'])
        if cash < -1e-7 or float(row['local_price']) <= 0 or (signed>0) != (row['side']=='BUY'):
            raise ValueError(f'Invalid execution fields {k} {date}')
        if k in account_count and account_count[k][0] > date:
            raise ValueError(f'Out-of-order execution {k} {date}')
        account_count[k]=date,cash
        counts[k]+=1
    for k,row in ledger.items():
        net=account_count[k][1]/1_000_000-1 if k in account_count else 0.
        if int(row['trades']) != counts[k] or abs(float(row['net'])-net)>1e-10:
            raise ValueError(f'Order reconciliation failed {k}')
    return dict(accounts=len(ledger),orders=sum(counts.values()))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--runs',type=Path,nargs='+',required=True)
    p.add_argument('--raw',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args()
    checks={}
    for run in a.runs:
        manifest=list(read(run/'data_manifest.csv'))
        for row in manifest:
            source=a.raw/(row['symbol']+'.json')
            if hashlib.sha256(source.read_bytes()).hexdigest()!=row['sha256']:
                raise ValueError(f'Changed source {source}')
        checks[run.parent.name]=dict(replay(run),raw_inputs=len(manifest))
    a.out.write_text(json.dumps(checks,indent=2)+'\n')
