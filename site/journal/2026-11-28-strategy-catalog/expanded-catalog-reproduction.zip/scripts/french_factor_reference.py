"""Compare published US long-only factor portfolio series to the US market total return."""
import argparse
import csv
import hashlib
import io
import math
import re
import statistics
import zipfile
from pathlib import Path
from urllib.request import Request, urlopen

BASE='https://mba.tuck.dartmouth.edu/pages/faculty/Ken.french/ftp/'
FILES={'market':'F-F_Research_Data_Factors_CSV.zip','value':'Portfolios_Formed_on_BE-ME_CSV.zip',
       'profitability':'Portfolios_Formed_on_OP_CSV.zip','accruals':'Portfolios_Formed_on_AC_CSV.zip',
       'momentum':'10_Portfolios_Prior_12_2_CSV.zip'}


def acquire(name,path):
    if not path.exists():
        with urlopen(Request(BASE+name,headers={'User-Agent':'FINTOS research'}),timeout=30) as r:
            data=r.read()
        if not zipfile.is_zipfile(io.BytesIO(data)):
            raise ValueError(name)
        path.write_bytes(data)
    with zipfile.ZipFile(path) as z:
        body=z.read(z.namelist()[0]).decode('latin1')
    if not (re.search(r'value[- ]weight(?:ed)?',body,re.I) or name==FILES['market']):
        raise ValueError('unrecognized weighting: '+name)
    rows={}
    header=[]
    for r in csv.reader(io.StringIO(body)):
        if r and not r[0].strip() and len(r)>2:
            header=[c.strip() for c in r]
        if r and re.fullmatch(r'(19|20)\d{4}',r[0].strip()):
            rows[r[0].strip()]=[float(x) for x in r[1:]]
        elif rows:
            break
    if not rows:
        raise ValueError('no monthly rows: '+name)
    return rows,header


def metric(rs):
    nav,peak,dd=1.,1.,0.
    for r in rs:
        nav*=1+r
        peak=max(peak,nav)
        dd=min(dd,nav/peak-1)
    return nav-1,dd


def reference(out,start,end):
    raw=out/'raw'
    raw.mkdir(parents=True,exist_ok=True)
    series,manifest={},[]
    for key,name in FILES.items():
        path=raw/name
        rows,header=acquire(name,path)
        if key=='market':
            values={d:(v[0]+v[3])/100 for d,v in rows.items() if min(v[0],v[3])>-90}
            column='Mkt-RF + RF'
        else:
            # Last 3 of 10 deciles except accruals, where low is preferred.
            start_column = len(next(iter(rows.values()))) - 10
            if start_column < 0 or not header[start_column+1].lower().startswith('lo') or not header[-1].lower().startswith('hi'):
                raise ValueError('cannot isolate deciles: '+str(header))
            col=range(start_column,start_column+3) if key=='accruals' else range(start_column+7,start_column+10)
            values={d:statistics.mean(v[j] for j in col)/100 for d,v in rows.items() if min(v[j] for j in col)>-90}
            column='; '.join(header[j+1] for j in col)
        series[key]=values
        manifest.append(dict(strategy=key,source=BASE+name,first=min(values),last=max(values),columns=column,
                             sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    dates=sorted(d for d in set.intersection(*(set(x) for x in series.values())) if start<=d<=end)
    if not dates:
        raise ValueError('no shared evaluation dates')
    results=[]
    for n in (12,24):
        changes={k:[] for k in series}
        mdds={k:[] for k in series}
        for i in range(len(dates)-n+1):
            window=dates[i:i+n]
            for k,returns in series.items():
                ret,dd=metric([returns[d] for d in window])
                changes[k].append(ret)
                mdds[k].append(dd)
        for k in series:
            deltas=[x-y for x,y in zip(changes[k],changes['market'])]
            results.append(dict(strategy=k,months=n,first=dates[0],last=dates[-1],accounts=len(deltas),
                                median_net=statistics.median(changes[k]),median_mdd=statistics.median(mdds[k]),
                                paired_vs_market=statistics.median(deltas),wins=sum(d>1e-10 for d in deltas)))
    for name,records in [('reference_summary',results),('reference_manifest',manifest)]:
        with (out/(name+'.csv')).open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(records[0]),lineterminator='\n')
            w.writeheader()
            w.writerows(records)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out',type=Path,required=True)
    p.add_argument('--start',default='202112')
    p.add_argument('--end',default='202610')
    a=p.parse_args()
    reference(a.out,a.start,a.end)
