"""Evaluate walk-forward own-factor ridge timing against style and market baselines."""
import argparse
import math
from pathlib import Path
from statistics import mean, median, stdev

from french_factor_reference import metric
from run_public_factor_followup import STYLE, export, fetch, loadings

PENALTIES = (.01, .1, 1., 10.)
SHRINK = (.25, .5, .75, 1.)
VALIDATION = '200001'
TRAIN_START = '198001'


def predict(training, xs, alpha):
    columns = tuple(zip(*(x for x, _ in training)))
    center = [mean(c) for c in columns]
    scale = [stdev(c) or 1. for c in columns]
    standardized = lambda x: [1., *((a-b)/c for a,b,c in zip(x,center,scale))]
    design = [standardized(x) for x,_ in training]
    response = [y for _,y in training]
    penalty = math.sqrt(alpha * len(training))
    coefficients = loadings(design+[[0.,penalty,0.],[0.,0.,penalty]], response+[0.,0.])
    return sum(b*z for b,z in zip(coefficients,standardized(xs))), coefficients[0]


def style_weights(scores):
    gross = sum(map(abs,scores))
    return tuple(x/gross for x in scores) if gross > 1e-14 else (.25,)*4


def path(data, dates, trades, mode, cost):
    previous = (.25,)*4
    rows = []
    for i, weights in trades:
        rf = data[dates[i]]['RF']
        raw_turnover = sum(abs(w-v) for w,v in zip(weights,previous))
        exposure = sum(w * data[dates[i]][f] for w,f in zip(weights,STYLE))
        # No transaction estimate for the unreplicated published market series.
        ret = rf + (data[dates[i]]['Mkt-RF'] if mode=='market' else exposure - cost*raw_turnover)
        rows.append(dict(month=dates[i], ret=ret, turnover=raw_turnover,
                         **dict(zip(STYLE,weights))))
        previous = weights
    return rows


def run(raw, out, first, last):
    archive, source = fetch(raw,'ff5')
    dates = sorted(x for x in archive if TRAIN_START<=x<=last)
    serial = [int(m[:4])*12+int(m[4:]) for m in dates]
    if any(b-a!=1 for a,b in zip(serial,serial[1:])):
        raise ValueError('missing calendar months')
    xs = {f:{i:tuple(sum(archive[m][f] for m in dates[i-k-1:i-1]) for k in (3,12))
             for i in range(13,len(dates))} for f in STYLE}
    validation = {(a,s):[] for a in PENALTIES for s in SHRINK}
    testing = {(a,s):[] for a in PENALTIES for s in SHRINK}
    static, sign = [], []
    for i, month in enumerate(dates):
        if month < VALIDATION:
            continue
        if i < 73:
            raise ValueError('insufficient expanding training history')
        static.append((i,(.25,)*4))
        sign.append((i,tuple(.25 if xs[f][i][1]>0 else -.25 for f in STYLE)))
        for alpha in PENALTIES:
            effects = [predict([(xs[f][j],archive[dates[j]][f]) for j in range(13,i-1)],xs[f][i],alpha)
                       for f in STYLE]
            for shrink in SHRINK:
                weights = style_weights([(1-shrink)*p+shrink*c for p,c in effects])
                if month < first:
                    validation[alpha,shrink].append((i,weights))
                else:
                    testing[alpha,shrink].append((i,weights))
    ranking = []
    for (alpha,shrink), trades in validation.items():
        rs = [r['ret'] for r in path(archive,dates,trades,'ridge',.001)]
        ranking.append(dict(alpha=alpha,shrink=shrink,first=dates[trades[0][0]],
                            last=dates[trades[-1][0]],months=len(rs),validation_sharpe=mean(rs)/stdev(rs)*math.sqrt(12)))
    ranking.sort(key=lambda r:(-r['validation_sharpe'],r['alpha'],r['shrink']))
    winner = ranking[0]['alpha'], ranking[0]['shrink']
    static = [row for row in static if dates[row[0]]>=first]
    sign = [row for row in sign if dates[row[0]]>=first]
    if len(static)<24:
        raise ValueError('less than 24 test months')
    results, months = [], []
    for cost in (0.,.001):
        outputs = {name:path(archive,dates,trades,name,cost) for name,trades in
                   [('market',static),('static',static),('sign',sign),('ridge',testing[winner])]}
        for name, stream in outputs.items():
            months.extend(dict(model=name,cost=cost,**row) for row in stream)
            for h in (12,24):
                metrics = lambda rr:[metric(row['ret'] for row in rr[i:i+h]) for i in range(len(rr)-h+1)]
                net, mdd = zip(*metrics(stream))
                against = {k:median(x-y[0] for x,y in zip(net,metrics(outputs[k]))) for k in ('static','sign','market')}
                results.append(dict(model=name,cost=cost,months=h,n=len(net),first=stream[0]['month'],
                    last=stream[-1]['month'],median_net=median(net),median_mdd=median(mdd),
                    paired_vs_static=against['static'],paired_vs_sign=against['sign'],
                    paired_vs_market=against['market'],mean_monthly_factor_turnover=mean(row['turnover'] for row in stream)))
    out.mkdir(parents=True,exist_ok=True)
    for name, result in [('factor_timing_shrinkage',results),('factor_timing_shrinkage_months',months),
                         ('factor_timing_shrinkage_validation',ranking),('factor_timing_shrinkage_source',[source])]:
        export(out,name,result)


if __name__=='__main__':
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--raw',type=Path,required=True)
    cli.add_argument('--out',type=Path,required=True)
    cli.add_argument('--start',default='202112')
    cli.add_argument('--end',default='202610')
    args=cli.parse_args()
    run(args.raw,args.out,args.start,args.end)
