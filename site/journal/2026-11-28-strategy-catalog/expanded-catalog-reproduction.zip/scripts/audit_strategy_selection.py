"""Compare early and later rankings without crossing the evaluation boundary."""
import argparse
import csv
from collections import defaultdict
from pathlib import Path
from statistics import median

from compare_strategy_catalog import cohort_key, read


def rankings(rows, boundary):
    scores = defaultdict(list)
    for row in rows:
        if row['portfolio'] != 'mixed' or row['strategy'] == 'hold':
            continue
        horizon, entry, exit_ = cohort_key(row)
        sample = 'estimation' if exit_ < boundary else 'evaluation' if entry >= boundary else None
        if sample:
            scores[row['cost_case'], horizon, sample, row['strategy']].append(float(row['paired_vs_hold']))
    for cost in sorted({key[0] for key in scores}):
        for horizon in (12, 24):
            samples = {sample: {s: values for (c,h,part,s),values in scores.items()
                                if (c,h,part)==(cost,horizon,sample)}
                       for sample in ('estimation','evaluation')}
            earlier, later = samples.values()
            if earlier.keys() != later.keys() or len(earlier) < 2:
                raise ValueError('incomplete ranking panel')
            order = lambda pool: sorted(pool,key=lambda s:(-median(pool[s]),s))
            before, after = order(earlier), order(later)
            for s in before:
                yield dict(cost_case=cost, months=horizon, strategy=s,
                           estimation_rank=before.index(s)+1, evaluation_rank=after.index(s)+1,
                           estimation_n=len(earlier[s]), evaluation_n=len(later[s]),
                           estimation_median=median(earlier[s]), evaluation_median=median(later[s]))


if __name__ == '__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    p.add_argument('--boundary',default='202111')
    a=p.parse_args()
    rows=list(rankings(read(a.input),a.boundary))
    with a.out.open('w',newline='') as f:
        w=csv.DictWriter(f,list(rows[0]),lineterminator='\n')
        w.writeheader(); w.writerows(rows)
