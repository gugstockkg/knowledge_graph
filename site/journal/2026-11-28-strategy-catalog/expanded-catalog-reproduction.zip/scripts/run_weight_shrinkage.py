"""Compare a fixed portfolio-weight blend with its component strategies."""

import argparse
import csv
from pathlib import Path
from statistics import median

import portfolio_engine as engine
from relative_partial_experiment import INITIAL_NAV, ORDER_FIELDS, OrderLedger
from run_research import monthly_book, unavailable_maturities


STRATEGIES = ('hold', 'min_variance', 'equal_market', 'weight_shrinkage')


def evaluate(study, start, end, writer):
    book = monthly_book(study, 'mixed')
    rules = {name: book[name] for name in ('min_variance', 'equal_market')}
    rules['weight_shrinkage'] = {
        day: {asset: (minimum[asset] + rules['equal_market'][day][asset]) / 2
              for asset in engine.ASSETS}
        for day, minimum in rules['min_variance'].items()
    }
    study.research_rules = rules
    data_end = min(max(item[0]) for item in study.data.values())
    unavailable = unavailable_maturities(study, data_end)
    cohorts = []
    for cost in (1, 2):
        case = f'{cost}x'
        study.transaction_cost = engine.COST * cost
        study.fx_cost = engine.FX_COST * cost
        for entry in study.months.values():
            if entry < start:
                continue
            for horizon in (12, 24):
                month = engine.month_shift(entry, horizon)
                deadline = study.months.get((month.year, month.month))
                if (deadline is None or deadline > end or deadline in unavailable
                        or (month.year, month.month) >= (data_end.year, data_end.month)):
                    continue
                account = {}
                for strategy in STRATEGIES:
                    ledger = OrderLedger(writer, case)
                    row = study.run(entry, deadline, 'mixed', strategy, ledger)
                    row.update(months=horizon, cost_case=case, cost_krw=ledger.cost,
                               adjustment_turnover=ledger.rebalances / INITIAL_NAV)
                    account[strategy] = row
                for row in account.values():
                    row['paired_vs_hold'] = row['net'] - account['hold']['net']
                    row['paired_vs_min_variance'] = row['net'] - account['min_variance']['net']
                    row['paired_vs_equal_market'] = row['net'] - account['equal_market']['net']
                    cohorts.append(row)
    return cohorts


def summarize(cohorts):
    fields = ('net', 'max_drawdown', 'cost_krw', 'adjustment_turnover',
              'paired_vs_hold', 'paired_vs_min_variance', 'paired_vs_equal_market')
    return [
        dict(cost_case=case, months=horizon, strategy=strategy, n=len(rows),
             **{f'median_{field}': median(row[field] for row in rows) for field in fields},
             wins_vs_hold=sum(row['paired_vs_hold'] > 1e-8 for row in rows),
             wins_vs_min_variance=sum(row['paired_vs_min_variance'] > 1e-8 for row in rows))
        for case in ('1x', '2x')
        for horizon in (12, 24)
        for strategy in STRATEGIES
        if (rows := [r for r in cohorts
                     if (r['cost_case'], r['months'], r['strategy']) == (case, horizon, strategy)])
    ]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--raw', required=True, type=Path)
    parser.add_argument('--out', required=True, type=Path)
    parser.add_argument('--start', type=engine.iso, default=engine.iso('2021-11-01'))
    parser.add_argument('--end', type=engine.iso, default=engine.iso('2026-09-30'))
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    data = {asset: engine.fetch(asset, args.raw, engine.month_shift(args.start, -13),
                                engine.month_shift(args.end, 1))
            for asset in (*engine.ASSETS, engine.FX)}
    engine.dump_csv(args.out / 'data_manifest.csv', [row[3] for row in data.values()])
    with (args.out / 'orders.csv').open('w', newline='') as stream:
        writer = csv.writer(stream, lineterminator='\n')
        writer.writerow((*ORDER_FIELDS, 'notional_krw', 'cost_case'))
        cohorts = evaluate(engine.Study(data), args.start, args.end, writer)
    if not cohorts:
        raise ValueError('No common eligible cohorts')
    engine.dump_csv(args.out / 'cohorts.csv', cohorts)
    engine.dump_csv(args.out / 'summary.csv', summarize(cohorts))


if __name__ == '__main__':
    main()
