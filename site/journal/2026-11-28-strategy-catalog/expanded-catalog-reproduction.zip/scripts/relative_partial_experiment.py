"""Compare full and partial relative-strength rebalancing on matched EC2 cohorts."""

import argparse
import csv
from pathlib import Path
from statistics import median

import portfolio_engine as engine
from run_research import unavailable_maturities

STRATEGIES = ('hold', 'relative', engine.RELATIVE_PARTIAL)
ORDER_FIELDS = ('portfolio', 'strategy', 'start', 'end', 'decision_date', 'trade_date',
                'symbol', 'side', 'reason', 'shares_signed', 'local_price', 'fx_krw',
                'cost_krw', 'cash_krw', 'holdings_asof', 'holdings_filing')
INITIAL_NAV = 1_000_000


class OrderLedger:
    def __init__(self, writer, cost_case):
        self.writer = writer
        self.cost_case = cost_case
        self.cost = self.gross = self.rebalances = 0.

    def writerow(self, row):
        record = dict(zip(ORDER_FIELDS, row))
        notional = abs(record['shares_signed']) * record['local_price'] * record['fx_krw']
        self.gross += notional
        self.cost += record['cost_krw']
        if record['reason'] not in ('initial', 'scheduled_deadline_close'):
            self.rebalances += notional
        self.writer.writerow((*row, notional, self.cost_case))


def evaluate(study, begin, end, writer, strategies=STRATEGIES):
    data_end = min(max(item[0]) for item in study.data.values())
    unavailable = unavailable_maturities(study, data_end)
    cohorts = []
    for cost in (1, 2):
        study.transaction_cost, study.fx_cost = engine.COST * cost, engine.FX_COST * cost
        for start in study.months.values():
            if start < begin:
                continue
            for horizon in (12, 24):
                month = engine.month_shift(start, horizon)
                deadline = study.months.get((month.year, month.month))
                if deadline is None or deadline > end or deadline in unavailable:
                    continue
                if (month.year, month.month) >= (data_end.year, data_end.month):
                    continue
                net = {}
                records = []
                for strategy in strategies:
                    ledger = OrderLedger(writer, f'{cost}x')
                    row = study.run(start, deadline, 'mixed', strategy, ledger)
                    net[strategy] = row['net']
                    row.update(months=horizon, cost_case=f'{cost}x', cost_krw=ledger.cost,
                               gross_turnover=ledger.gross / INITIAL_NAV,
                               adjustment_turnover=ledger.rebalances / INITIAL_NAV)
                    records.append(row)
                for row in records:
                    row.update(paired_vs_hold=row['net'] - net['hold'],
                               paired_vs_full=row['net'] - net['relative'])
                cohorts.extend(records)
    return cohorts


def summarize(cohorts, strategies=STRATEGIES):
    for case in ('1x', '2x'):
        for horizon in (12, 24):
            for strategy in strategies:
                rows = [r for r in cohorts if
                        (r['cost_case'], r['months'], r['strategy']) == (case, horizon, strategy)]
                if not rows:
                    continue
                fields = ('net', 'max_drawdown', 'paired_vs_hold', 'paired_vs_full',
                          'cost_krw', 'gross_turnover', 'adjustment_turnover')
                yield dict(cost_case=case, months=horizon, strategy=strategy, n=len(rows),
                           first_entry=min(r['start'] for r in rows),
                           last_exit=max(r['end'] for r in rows),
                           **{f'median_{key}': median(r[key] for r in rows) for key in fields},
                           wins_vs_full=sum(r['paired_vs_full'] > 1e-8 for r in rows),
                           targets=sum(r['target'] for r in rows))


def main(study_factory=engine.Study, strategies=STRATEGIES, description=__doc__):
    args = argparse.ArgumentParser(description=description)
    args.add_argument('--raw', type=Path, required=True)
    args.add_argument('--out', type=Path, required=True)
    args.add_argument('--start', type=engine.iso, default=engine.iso('2021-11-01'))
    args.add_argument('--end', type=engine.iso, default=engine.iso('2026-09-30'))
    a = args.parse_args()
    a.out.mkdir(parents=True, exist_ok=True)
    data = {symbol: engine.fetch(symbol, a.raw, engine.month_shift(a.start, -13),
                                 engine.month_shift(a.end, 1))
            for symbol in (*engine.ASSETS, engine.FX)}
    engine.dump_csv(a.out / 'data_manifest.csv', [row[3] for row in data.values()])
    with (a.out / 'orders.csv').open('w', newline='') as stream:
        writer = csv.writer(stream, lineterminator='\n')
        writer.writerow((*ORDER_FIELDS, 'notional_krw', 'cost_case'))
        cohorts = evaluate(study_factory(data), a.start, a.end, writer, strategies)
    if not cohorts:
        raise ValueError('No eligible rolling cohorts')
    engine.dump_csv(a.out / 'cohorts.csv', cohorts)
    engine.dump_csv(a.out / 'summary.csv', list(summarize(cohorts, strategies)))


if __name__ == '__main__':
    main()
