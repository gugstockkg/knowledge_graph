"""Reproduce public US factor timing and out-of-sample factor fit checks."""
import argparse
import csv
import hashlib
import io
import math
import re
import statistics
import zipfile
from pathlib import Path
from urllib.request import Request, urlopen

from french_factor_reference import BASE, metric

FILES = {
    'ff3': 'F-F_Research_Data_Factors_CSV.zip',
    'ff5': 'F-F_Research_Data_5_Factors_2x3_CSV.zip',
    'umd': 'F-F_Momentum_Factor_CSV.zip',
}
STYLE = ('SMB', 'HML', 'RMW', 'CMA')


def fetch(root, name):
    archive = root / FILES[name]
    if not archive.exists():
        with urlopen(Request(BASE + archive.name, headers={'User-Agent': 'FINTOS research'}), timeout=30) as r:
            body = r.read()
        if not zipfile.is_zipfile(io.BytesIO(body)):
            raise ValueError(f'Expected ZIP: {archive.name}')
        archive.write_bytes(body)
    body = archive.read_bytes()
    with zipfile.ZipFile(io.BytesIO(body)) as zipped:
        table = zipped.read(zipped.namelist()[0]).decode('latin1')
    columns, rows = [], {}
    for row in csv.reader(io.StringIO(table)):
        if row and not row[0].strip() and len(row) > 1 and all(x.strip() for x in row[1:]):
            columns = [x.strip() for x in row[1:]]
        if row and re.fullmatch(r'(19|20)\d{2}(0[1-9]|1[0-2])', row[0].strip()):
            values = [float(x) for x in row[1:]]
            if not columns or len(values) != len(columns):
                raise ValueError(f'Column mismatch: {archive.name}')
            if min(values) > -90:
                rows[row[0].strip()] = dict(zip(columns, (x / 100 for x in values)))
        elif rows:
            break
    if not rows:
        raise ValueError(f'No usable monthly observations: {archive.name}')
    return rows, {
        'source': BASE + archive.name, 'sha256': hashlib.sha256(body).hexdigest(),
        'first': min(rows), 'last': max(rows),
    }


def loadings(matrix, target):
    """Fit OLS using modified Gram-Schmidt and triangular back substitution."""
    q, triangular = [], []
    for column in zip(*matrix):
        projection = []
        remainder = list(column)
        for axis in q:
            weight = sum(x * y for x, y in zip(axis, remainder))
            projection.append(weight)
            remainder = [x - weight * y for x, y in zip(remainder, axis)]
        norm = math.sqrt(sum(x * x for x in remainder))
        if norm < 1e-12:
            raise ValueError('Singular exposure matrix')
        triangular.append([*projection, norm])
        q.append([x / norm for x in remainder])
    coeff = [sum(x * y for x, y in zip(axis, target)) for axis in q]
    for i in range(len(coeff) - 1, -1, -1):
        coeff[i] = (coeff[i] - sum(triangular[j][i] * coeff[j]
                                  for j in range(i + 1, len(coeff)))) / triangular[i][i]
    return coeff


def export(out, name, values):
    with (out / (name + '.csv')).open('w', newline='', encoding='utf-8') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(values[0]), lineterminator='\n')
        writer.writeheader()
        writer.writerows(values)


def run(out, first, last):
    raw = out / 'raw'
    raw.mkdir(parents=True, exist_ok=True)
    data, manifest = {}, []
    for key in FILES:
        data[key], info = fetch(raw, key)
        manifest.append(dict(dataset=key, **info))
    ff3, ff5, umd = (data[key] for key in FILES)
    months = sorted(m for m in ff5.keys() & ff3.keys() & umd.keys() if m <= last)
    month_idx = lambda value: int(value[:4]) * 12 + int(value[-2:])
    if any(month_idx(a) + 1 != month_idx(b) for a, b in zip(months, months[1:])):
        raise ValueError('Missing month in aligned dataset')
    training = [m for m in months if '200001' <= m < first]
    testing = [m for m in months if m >= first]
    if len(training) < 60 or len(testing) < 24:
        raise ValueError('Require at least 60 training and 24 evaluation observations')
    checks = []
    for model, source, columns in (
        ('ff3', ff3, ('Mkt-RF', 'SMB', 'HML')),
        ('ff5', ff5, ('Mkt-RF', *STYLE)),
    ):
        x = lambda m: [1., *(source[m][c] for c in columns)]
        y = lambda m: umd[m]['Mom']
        beta = loadings([x(m) for m in training], [y(m) for m in training])
        predicted = [sum(a * b for a, b in zip(x(m), beta)) for m in testing]
        mse = statistics.mean((y(m) - p) ** 2 for m, p in zip(testing, predicted))
        forecast = statistics.mean(y(m) for m in training)
        baseline = statistics.mean((y(m) - forecast) ** 2 for m in testing)
        checks.append(dict(model=model, target='published_US_stock_momentum_factor',
                           fit_first=training[0], fit_last=training[-1],
                           test_first=testing[0], test_last=testing[-1], test_months=len(testing),
                           rmse=math.sqrt(mse), intercept=beta[0], r2_vs_training_mean=1 - mse / baseline))

    observations = []
    for i, month in enumerate(months):
        if month < first:
            continue
        if i < 13:
            raise ValueError('Timing requires 13 prior months')
        # Exclude the immediately preceding month to allow one month for publication.
        history = months[i - 13:i - 1]
        signs = {f: 1 if sum(ff5[m][f] for m in history) > 0 else -1 for f in STYLE}
        cash = ff5[month]['RF']
        observations.append(dict(month=month,
            timed=cash + statistics.mean(ff5[month][f] * signs[f] for f in STYLE),
            static=cash + statistics.mean(ff5[month][f] for f in STYLE),
            market=cash + ff5[month]['Mkt-RF'], **{f + '_sign': signs[f] for f in STYLE}))
    results = []
    for horizon in (12, 24):
        windows = [observations[i:i + horizon] for i in range(len(observations) - horizon + 1)]
        market = [metric(r['market'] for r in w)[0] for w in windows]
        static = [metric(r['static'] for r in w)[0] for w in windows]
        for strategy in ('timed', 'static', 'market'):
            rv = [metric(r[strategy] for r in w) for w in windows]
            returns, mdds = zip(*rv)
            diff = [x - y for x, y in zip(returns, static)]
            results.append(dict(strategy=strategy, months=horizon, first=testing[0], last=testing[-1],
                                accounts=len(windows), median_total=statistics.median(returns),
                                median_mdd=statistics.median(mdds), paired_vs_static=statistics.median(diff),
                                wins_vs_static=sum(d > 1e-10 for d in diff),
                                paired_vs_market=statistics.median(x - y for x, y in zip(returns, market))))
    for name, values in (('manifest', manifest), ('exposures', checks), ('months', observations),
                         ('summary', results)):
        export(out, 'public_factor_' + name, values)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--start', default='202112')
    parser.add_argument('--end', default='202610')
    args = parser.parse_args()
    run(args.out, args.start, args.end)
