"""Compare original relative strength with one additional market session of lag."""

import bisect

import portfolio_engine as engine
from relative_partial_experiment import main

DELAYED = 'relative_delayed_rebalance'


class DelayedLedger:
    def __init__(self, ledger):
        self.ledger = ledger

    def writerow(self, row):
        self.ledger.writerow((row[0], DELAYED, *row[2:]))


class DelayedStudy(engine.Study):
    delay = False

    def defer_rebalance(self, symbol, decision, day, rule):
        if not self.delay or rule not in ('quarterly', 'signal_weight_change'):
            return False
        sessions = self.closes[symbol][0]
        return bisect.bisect_right(sessions, decision) == bisect.bisect_left(sessions, day)

    def run(self, start, deadline, portfolio, strategy, ledger):
        if strategy != DELAYED:
            return super().run(start, deadline, portfolio, strategy, ledger)
        self.delay = True
        try:
            row = super().run(start, deadline, portfolio, 'relative', DelayedLedger(ledger))
            row['strategy'] = DELAYED
            return row
        finally:
            self.delay = False


if __name__ == '__main__':
    main(DelayedStudy, ('hold', 'relative', DELAYED), __doc__)
