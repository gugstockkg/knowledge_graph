"""Compare Korean trended-momentum picks with nearest unused momentum ranks."""

import argparse
import math
from pathlib import Path
from statistics import median

from kr_factor_extension import months_apart, read_panel, simulate
from run_factor_backtest import dump
from run_kr_trended_momentum import form_ranks, trend_scores


def match_winners(broad, trended):
    winners = tuple(broad[:math.ceil(len(broad) / 5)])
    by_rank = {security: i for i, security in enumerate(winners)}
    available = set(winners) - set(trended)
    matches = []
    for security in sorted(trended, key=by_rank.__getitem__):
        rank = by_rank[security]
        match = min(available, key=lambda code: (abs(by_rank[code] - rank), by_rank[code]))
        available.remove(match)
        matches.append((security, match, rank + 1, by_rank[match] + 1))
    return matches


def run(args):
    panel = read_panel(args.input)
    dates = sorted(month for month in panel if month <= args.end)
    if not dates or dates[-1] != args.end or any(months_apart(a,b)!=1 for a,b in zip(dates,dates[1:])):
        raise ValueError('Missing monthly observation calendar')
    files = sorted(args.raw.glob('marcap-*.parquet'))
    if not files:
        raise ValueError('No archived marcap parquet inputs')
    clarity = {(month, code): value for month, code, value in trend_scores(files,args.start,args.end)
               if value is not None and math.isfinite(value)}
    pure, trend, matched, evidence = {}, {}, {}, []
    for i, month in enumerate(dates):
        if i < 12 or month < args.start:
            continue
        broad, normal, trended, past_returns = form_ranks(panel, dates, i, clarity)
        matches = match_winners(broad, trended)
        if len(matches) != len(trended) or len({m[1] for m in matches}) != len(trended):
            raise ValueError(f'Incomplete matching in {month}')
        pure[month] = broad, normal
        trend[month] = broad, trended
        matched[month] = broad, tuple(m[1] for m in matches)
        evidence.extend(dict(month=month, trend_security=t, matched_security=m,
                             trend_rank=tr, matched_rank=mr, abs_rank_distance=abs(tr-mr),
                             trend_momentum=past_returns[t], matched_momentum=past_returns[m],
                             trend_r2=clarity[month,t], matched_r2=clarity[month,m])
                        for t,m,tr,mr in matches)
    if args.start not in pure:
        raise ValueError('Missing warmup')
    cohorts = []
    summary = []
    for horizon in (12, 24):
        names = ('hold','momentum_same_size','momentum_rank_matched','trended_momentum')
        groups = {name: [] for name in names}
        for i, month in enumerate(dates[:-horizon]):
            if month not in pure:
                continue
            hold = simulate(panel, dates, pure, i, horizon, 'hold', .5, args.fee)
            normal = simulate(panel, dates, pure, i, horizon, 'momentum', .5, args.fee)
            control = simulate(panel, dates, matched, i, horizon, 'momentum', .5, args.fee)
            trended = simulate(panel, dates, trend, i, horizon, 'momentum', .5, args.fee)
            for name, row in zip(groups, (hold,normal,control,trended)):
                row.update(strategy=name, vs_hold=row['net']-hold['net'],
                           vs_matched=row['net']-control['net'])
                groups[name].append(row)
                cohorts.append(row)
        for name, rows in groups.items():
            summary.append(dict(months=horizon, recovery=.5, strategy=name, windows=len(rows),
                median_net=median(r['net'] for r in rows), median_mdd=median(r['mdd'] for r in rows),
                paired_vs_hold=median(r['vs_hold'] for r in rows),
                paired_vs_matched=median(r['vs_matched'] for r in rows),
                wins_vs_matched=sum(r['vs_matched']>0 for r in rows),
                targets=sum(r['target'] for r in rows)))
    args.out.mkdir(parents=True, exist_ok=True)
    dump(args.out/'kr_trended_matched_summary.csv', summary)
    dump(args.out/'kr_trended_matched_cohorts.csv', cohorts)
    dump(args.out/'kr_trended_matched_pairs.csv', evidence)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('input','raw','out'):
        parser.add_argument('--'+name, type=Path, required=True)
    parser.add_argument('--start',default='2021-11')
    parser.add_argument('--end',default='2026-10')
    parser.add_argument('--fee',type=float,default=.001)
    args = parser.parse_args()
    if not 0 <= args.fee <= .02:
        parser.error('fee must be between 0 and .02')
    run(args)
