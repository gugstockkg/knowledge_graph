"""Audit the sensitivity of published US style-factor comparisons to data vintage."""
import argparse
import csv
import hashlib
import io
import math
import re
import zipfile
from pathlib import Path
from statistics import mean, median, stdev
from urllib.request import Request, urlopen

from french_factor_reference import BASE, metric
from run_public_factor_followup import FILES, STYLE, export

LEGACY = BASE.replace('/ftp/', '/ftp_202412/')
MONTH = re.compile(r'(19|20)\d{2}(0[1-9]|1[0-2])')
FACTORS = ('Mkt-RF', *STYLE, 'RF')


def read_vintage(url, path):
    body = path.read_bytes() if path.exists() else urlopen(
        Request(url, headers={'User-Agent': 'FINTOS research'}), timeout=30).read()
    with zipfile.ZipFile(io.BytesIO(body)) as zipped:
        table = zipped.read(zipped.namelist()[0]).decode('latin1')
    rows = {}
    columns = []
    for row in csv.reader(io.StringIO(table)):
        if row and not row[0].strip() and tuple(c.strip() for c in row[1:]) == FACTORS:
            columns = list(FACTORS)
        if row and MONTH.fullmatch(row[0].strip()) and columns:
            values = [float(c) / 100 for c in row[1:]]
            if len(values) != len(columns) or min(values) < -.9 or row[0] in rows:
                raise ValueError(f'Invalid factor observation {row}')
            rows[row[0]] = dict(zip(columns, values))
        elif rows:
            break
    if not rows:
        raise ValueError(f'No monthly factors in {url}')
    if not path.exists():
        path.write_bytes(body)
    return rows, dict(source=url, sha256=hashlib.sha256(body).hexdigest(),
                      first=min(rows), last=max(rows))


def run(raw, out, start, end):
    raw.mkdir(parents=True, exist_ok=True)
    name = FILES['ff5']
    manifest = []
    vintages = {}
    for name_, base in [('fiz', LEGACY), ('ciz', BASE)]:
        vintages[name_], provenance = read_vintage(base + name, raw / (name_ + '-' + name))
        manifest.append(dict(vintage=name_, **provenance))
    dates = sorted(vintages['fiz'].keys() & vintages['ciz'].keys())
    month_numbers = [int(m[:4]) * 12 + int(m[4:]) for m in dates]
    if any(right - left != 1 for left, right in zip(month_numbers, month_numbers[1:])):
        raise ValueError('Missing shared data month')
    selected = [(i, month) for i, month in enumerate(dates) if start <= month <= end]
    if len(selected) < 24 or selected[0][0] < 13:
        raise ValueError('Both vintages require 24 common evaluation months plus 13 months of history')
    paths = []
    for label, vintage in vintages.items():
        for i, month in selected:
            factors = vintage[month]
            history = dates[i - 13:i - 1]
            signs = {f: 1 if sum(vintage[m][f] for m in history) > 0 else -1 for f in STYLE}
            cash = factors['RF']
            paths.append(dict(vintage=label, month=month, market=factors['Mkt-RF']+cash,
                              static=mean(factors[f] for f in STYLE)+cash,
                              sign=mean(signs[f]*factors[f] for f in STYLE)+cash,
                              **{f + '_sign': v for f, v in signs.items()}))
    summary = []
    refs = {label: [row for row in paths if row['vintage'] == label] for label in vintages}
    for horizon in (12, 24):
        for strategy in ('market', 'static', 'sign'):
            observations = {
                label: [metric(row[strategy] for row in values[i:i+horizon])[0]
                        for i in range(len(values)-horizon+1)] for label,values in refs.items()}
            delta = [c - f for c, f in zip(observations['ciz'], observations['fiz'])]
            sign_change = sum(a[f+'_sign'] != b[f+'_sign']
                              for a,b in zip(refs['ciz'], refs['fiz']) for f in STYLE) if strategy == 'sign' else 0
            summary.append(dict(strategy=strategy, horizon=horizon, windows=len(delta), first=selected[0][1],
                last=selected[-1][1], median_fiz=median(observations['fiz']), median_ciz=median(observations['ciz']),
                paired_vintage_delta=median(delta), max_abs_vintage_delta=max(map(abs, delta)),
                sign_disagreements=sign_change))
    details = []
    for factor in FACTORS:
        values = {label: [vintage[m][factor] for _,m in selected] for label,vintage in vintages.items()}
        vintage_diff = [c - f for c, f in zip(values['ciz'], values['fiz'])]
        if factor == 'RF':
            sharpe = {'fiz': '', 'ciz': ''}
        else:
            sharpe = {label: mean(series)/stdev(series)*math.sqrt(12) for label,series in values.items()}
        details.append(dict(factor=factor, count=len(vintage_diff),
                            changed_months=sum(abs(d) > 1e-12 for d in vintage_diff),
                            mean_absolute_delta=mean(map(abs,vintage_diff)),
                            maximum_absolute_delta=max(map(abs,vintage_diff)),
                            sharpe_fiz=sharpe['fiz'], sharpe_ciz=sharpe['ciz']))
    out.mkdir(parents=True, exist_ok=True)
    for label, rows in [('summary', summary), ('months', paths), ('factor_deltas', details), ('manifest', manifest)]:
        export(out, 'french_vintage_' + label, rows)


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--raw', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--start', default='202112')
    p.add_argument('--end', default='202412')
    a = p.parse_args()
    run(a.raw, a.out, a.start, a.end)
