"""Compare dependence across backtest design paths on common factor observations."""
import argparse
import itertools
import random
from pathlib import Path
from math import sqrt
from statistics import mean, pstdev, stdev

from run_public_factor_followup import STYLE, export, fetch

FORMATIONS = (6, 12)
TILTS = (.5, 1.)
COSTS = (0., .001)


def paths(rows, first, last):
    dates = sorted(rows)
    ordinal = [int(value[:4])*12 + int(value[4:]) for value in dates]
    if any(b-a != 1 for a,b in zip(ordinal, ordinal[1:])):
        raise ValueError('Missing factor month')
    dates_selected = [(i,m) for i,m in enumerate(dates) if first <= m <= last]
    if not dates_selected or dates_selected[0][0] < 13:
        raise ValueError('Evaluation period requires 13 prior monthly observations')
    results = {}
    for formation, tilt, cost in itertools.product(FORMATIONS, TILTS, COSTS):
        series = []
        previous = (.25,)*4
        for i, month in dates_selected:
            history = dates[i-formation-1:i-1]
            signs = [1 if sum(rows[m][f] for m in history) > 0 else -1 for f in STYLE]
            weights = tuple((1-tilt)*.25+tilt*.25*sign for sign in signs)
            turnover = sum(abs(w-v) for w,v in zip(weights,previous))
            excess = sum((w-.25)*rows[month][f] for w,f in zip(weights,STYLE))-cost*turnover
            series.append(excess)
            previous = weights
        results[formation, tilt, cost] = series
    return [month for _,month in dates_selected], results


def draw(rng, n, block):
    starts = [rng.randrange(n) for _ in range((n+block-1)//block)]
    return [(first+offset)%n for first in starts for offset in range(block)][:n]


def correlation(a,b):
    center_a, center_b = mean(a), mean(b)
    pairs = [(x-center_a,y-center_b) for x,y in zip(a,b)]
    return sum(x*y for x,y in pairs) / sqrt(sum(x*x for x,_ in pairs)*sum(y*y for _,y in pairs))


def bootstrap(results, draws, block, seed, shared):
    rng = random.Random(seed)
    estimates = {config:[] for config in results}
    n = len(next(iter(results.values())))
    for _ in range(draws):
        common = draw(rng,n,block) if shared else None
        for config, values in results.items():
            indices = common if shared else draw(rng,n,block)
            estimates[config].append(mean(values[i] for i in indices))
    correlations = [correlation(a,b) for a,b in itertools.combinations(estimates.values(),2)]
    estimates_pooled = [mean(row) for row in zip(*estimates.values())]
    return dict(mean_abs_path_correlation=mean(map(abs, correlations)),
                mean_path_correlation=mean(correlations),
                pooled_bootstrap_sd=stdev(estimates_pooled),
                mean_within_path_bootstrap_sd=mean(stdev(xs) for xs in estimates.values()))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--raw', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--start', default='202112')
    parser.add_argument('--end', default='202609')
    parser.add_argument('--draws', type=int, default=1000)
    parser.add_argument('--seed', type=int, default=1511)
    args = parser.parse_args()
    if args.draws < 50:
        parser.error('At least 50 draws are required')
    data, provenance = fetch(args.raw, 'ff5')
    dates, results = paths(data,args.start,args.end)
    if len(dates) < 24:
        raise ValueError('Need at least 24 monthly observations')
    metadata = dict(path_count=len(results), windows=len(dates), first=dates[0], last=dates[-1],
                    draws=args.draws, seed=args.seed,
                    cross_path_mean=mean(mean(x) for x in results.values()),
                    cross_path_sd=pstdev([mean(x) for x in results.values()]))
    summary = [dict(mode='common' if shared else 'path_specific', block_months=block, **metadata,
                    **bootstrap(results,args.draws,block,args.seed,shared))
               for block in (3,6,12) for shared in (True,False)]
    configs = [dict(formation_months=f,tilt=t,cost=c,mean_monthly_excess=mean(series))
               for (f,t,c),series in results.items()]
    args.out.mkdir(parents=True,exist_ok=True)
    export(args.out,'factor_design_bootstrap',summary)
    export(args.out,'factor_design_paths',configs)
    export(args.out,'factor_design_manifest',[provenance])


if __name__ == '__main__':
    main()
