"""Audit selection-ledger information dates against dated SEC filing records.

Inspired by DeepFund's explicit separation of information availability and
evaluation time. This is a monthly deterministic filing audit.
"""
import argparse
import json
from collections import Counter
from datetime import date
from pathlib import Path

from run_factor_backtest import dump, read

FILING_FACTORS = {'value', 'profitability', 'accruals'}


def month_start(value):
    if len(value) != 7:
        raise ValueError('expected YYYY-MM')
    return date.fromisoformat(value + '-01')


def filing_dates(records):
    index = {}
    for row in records:
        key = row['issuer'], row['accession']
        published = date.fromisoformat(row['published'])
        previous = index.setdefault(key, published)
        if published != previous:
            raise ValueError(f'conflicting SEC publication dates for {key}')
    return index


def categorize(row, filings):
    signal = month_start(row['signal_month'])
    trade = month_start(row['trade_month'])
    if signal >= trade:
        return 'signal_not_before_trade', ''
    factor = row['factor']
    if factor == 'momentum':
        return 'unverified_price_provenance', ''
    if factor not in FILING_FACTORS:
        return 'unknown_factor', ''
    if not row['filing'] or not row['published']:
        return 'missing_filing_metadata', ''
    key = row['cik'], row['filing']
    publication = filings.get(key)
    if publication is None:
        return 'filing_not_in_sec_index', ''
    if date.fromisoformat(row['published']) != publication:
        return 'filing_publication_mismatch', ''
    if publication >= signal:
        return 'filing_not_before_signal', ''
    shares_date = ''
    if factor == 'value':
        shares = filings.get((row['cik'], row['shares_filing']))
        if shares is None:
            return 'shares_filing_not_in_sec_index', ''
        shares_date = shares.isoformat()
        if shares >= signal:
            return 'shares_filing_not_before_signal', shares_date
    return 'verified_filing_timing', shares_date


def audit(rows, filings):
    seen = set()
    audited = []
    for row in rows:
        key = row['trade_month'], row['factor'], row['ticker']
        try:
            status, shares_date = categorize(row, filings)
        except ValueError:
            status, shares_date = 'invalid_date', ''
        if key in seen:
            status, shares_date = 'duplicate_selection', ''
        seen.add(key)
        audited.append(dict(row, timing_status=status, shares_available_date=shares_date))
    return audited


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('selections', 'sec-filings', 'out'):
        parser.add_argument('--'+name, type=Path, required=True)
    args = parser.parse_args()
    rows = audit(read(args.selections), filing_dates(read(args.sec_filings)))
    if not rows:
        parser.error('empty selections ledger')
    summary = dict(sorted(Counter(row['timing_status'] for row in rows).items()))
    args.out.mkdir(parents=True, exist_ok=True)
    dump(args.out/'factor_information_timing_rows.csv', rows)
    (args.out/'factor_information_timing_summary.json').write_text(
        json.dumps({'total':len(rows), 'by_status':summary}, indent=2)+'\n', encoding='utf-8')
    if set(summary)-{'verified_filing_timing', 'unverified_price_provenance'}:
        raise SystemExit('Timing audit found contradictions. Inspect the row output.')


if __name__ == '__main__':
    main()
