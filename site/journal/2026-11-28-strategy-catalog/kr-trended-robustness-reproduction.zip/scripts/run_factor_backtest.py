"""Run a paired, monthly factor pilot from a fully dated historical security panel."""
import argparse
import csv
import math
from collections import defaultdict
from pathlib import Path
from statistics import median

FACTORS = ('value', 'profitability', 'accruals', 'momentum')


def number(s):
    if not s:
        return None
    x = float(s)
    if not math.isfinite(x):
        raise ValueError(s)
    return x


def read(path):
    with path.open(newline='', encoding='utf-8-sig') as f:
        yield from csv.DictReader(f)


def dump(path, rows):
    with path.open('w', newline='', encoding='utf-8') as f:
        if rows:
            w = csv.DictWriter(f, fieldnames=list(rows[0]), lineterminator='\n')
            w.writeheader()
            w.writerows(rows)


def load(prices, financials):
    panel = defaultdict(dict)
    filings = defaultdict(list)
    for row in read(prices):
        key = row['market'], row['security']
        if key in panel[row['month']]:
            raise ValueError(f'duplicate series {row}')
        if row['market'] not in ('KR', 'US') or row['terminal'] not in ('0','1'):
            raise ValueError(row)
        if row['terminal']=='1' and (not row.get('terminal_source') or not row['krw_return']):
            raise ValueError(f'terminal return provenance unavailable: {key} {row["month"]}')
        panel[row['month']][key] = dict(
            equity=number(row['market_cap']), local=number(row['local_return']),
            krw=number(row['krw_return']), terminal=row['terminal']=='1',
            eligible=row['eligible']=='1', issuer=row['issuer'])
    for row in read(financials):
        key = row['market'], row['issuer']
        if row['published'] < row['fiscal_end'] or len(row['published']) != 10 or not row['accession']:
            raise ValueError(f'invalid date provenance {row}')
        filings[key].append(row)
    return panel, filings


def features(panel, filings, dates, i, key):
    now = dates[i]
    row = panel[now][key]
    # Use filings from months strictly earlier than the decision month.
    versions = [v for v in filings[key[0],row['issuer']] if v['published'][:7] < now]
    f = max(versions, key=lambda x:(x['fiscal_end'],x['published'],x['accession'])) if versions else {}
    eq, a = number(f.get('book_equity')), number(f.get('assets'))
    op, ni, ocf = [number(f.get(k)) for k in ('gross_profit','net_income','operating_cash_flow')]
    history = [panel[m].get(key,{}).get('local') for m in dates[max(0,i-11):i]]
    return dict(value=eq/row['equity'] if eq and eq>0 and row['equity'] and row['equity']>0 else None,
                profitability=op/a if op is not None and a and a>0 else None,
                accruals=-(ni-ocf)/a if ni is not None and ocf is not None and a and a>0 else None,
                momentum=math.prod(1+x for x in history)-1 if len(history)==11 and None not in history else None,
                published=f.get('published',''), accession=f.get('accession',''),
                fiscal_end=f.get('fiscal_end',''))


def allocate(scores, factor):
    target = {}
    for country in ('KR','US'):
        pool = [(values[factor],key) for key,values in scores.items()
                if key[0]==country and values[factor] is not None]
        if len(pool)<10:
            return None
        chosen = sorted(pool, key=lambda x:(-x[0],x[1]))[:max(1,math.ceil(.3*len(pool)))]
        target.update({key:.5/len(chosen) for _,key in chosen})
    return target


def simulate(strategy, start, spans, panel, dates, targets, fee, orders):
    cash, positions, peak, drawdown, turnover = 1., {}, 1., 0., 0.
    for i in range(start, start+spans):
        day = dates[i]
        if i==start or strategy!='hold' and i%3==start%3:
            desired = targets[day][strategy]
            if desired is None:
                raise ValueError(f'insufficient score coverage {day}: {strategy}')
            nav = cash+sum(positions.values())
            # Solve post-cost NAV so cash and actual order costs reconcile.
            names=positions.keys()|desired.keys()
            budget=nav
            for _ in range(12):
                total=sum(abs(budget*desired.get(k,0)-positions.get(k,0)) for k in names)
                budget=nav-total*fee
            total=sum(abs(budget*desired.get(k,0)-positions.get(k,0)) for k in names)
            if not math.isclose(budget, nav-total*fee, abs_tol=1e-12):
                raise ValueError('trade costs did not converge')
            for k in sorted(names):
                change=budget*desired.get(k,0)-positions.get(k,0)
                if abs(change)>1e-10:
                    orders.append(dict(start=dates[start],months=spans,strategy=strategy,month=day,
                                       market=k[0],security=k[1],notional=change,fee=abs(change)*fee))
            positions={k:budget*w for k,w in desired.items()}
            cash=budget-sum(positions.values())
            turnover+=total/nav
        observed=panel[dates[i+1]]
        for k in list(positions):
            r=observed.get(k)
            if r is None or r['krw'] is None or r['krw'] < -1:
                raise ValueError(f'missing holding or terminal total return {dates[i+1]} {k}')
            positions[k]*=1+r['krw']
            if r['terminal']:
                cash+=positions.pop(k)
        nav=cash+sum(positions.values())
        peak=max(peak,nav)
        drawdown=min(drawdown,nav/peak-1)
    residual=sum(positions.values())
    end=cash+residual*(1-fee)
    if residual:
        turnover+=residual/(cash+residual)
        for k,value in sorted(positions.items()):
            if value:
                orders.append(dict(start=dates[start],months=spans,strategy=strategy,month=dates[start+spans],
                                   market=k[0],security=k[1],notional=-value,fee=value*fee))
    drawdown=min(drawdown,end/peak-1)
    return dict(start=dates[start],end=dates[start+spans],months=spans,strategy=strategy,
                net=end-1,monthly_drawdown=drawdown,turnover=turnover,target=int(end>=1.15))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--returns',type=Path,required=True)
    p.add_argument('--filings',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    p.add_argument('--start',default='2021-11')
    p.add_argument('--end',default='2026-10')
    p.add_argument('--fee',type=float,default=.001)
    a=p.parse_args()
    if not math.isfinite(a.fee) or not 0<=a.fee<=.02:
        p.error('fee must be between 0 and 0.02')
    panel,filings=load(a.returns,a.filings)
    dates=sorted(m for m in panel if m<=a.end)
    from datetime import date
    mo=lambda d: date.fromisoformat(d+'-01').year*12+date.fromisoformat(d+'-01').month
    if any(mo(y)-mo(x)!=1 for x,y in zip(dates,dates[1:])):
        p.error('monthly return panel contains calendar gaps')
    targets,coverage,evidence={},[],[]
    for i,day in enumerate(dates):
        if day<a.start:
            continue
        prior=panel[dates[i-1]] if i else {}
        scores={k:features(panel,filings,dates,i-1,k) for k,r in panel[day].items()
                if r['eligible'] and not r['terminal'] and k in prior
                and prior[k]['eligible'] and not prior[k]['terminal']}
        counts={m:sum(k[0]==m for k in scores) for m in ('KR','US')}
        targets[day]={f:allocate(scores,f) for f in FACTORS}
        targets[day]['hold']={k:.5/counts[k[0]] for k in scores} if min(counts.values())>=10 else None
        for f in FACTORS:
            selection=targets[day][f] or {}
            for k,weight in selection.items():
                score=scores[k]
                evidence.append(dict(month=day,factor=f,market=k[0],security=k[1],
                    score=score[f],weight=weight,accession=score['accession'] if f!='momentum' else '',
                    published=score['published'] if f!='momentum' else '',
                    fiscal_end=score['fiscal_end'] if f!='momentum' else ''))
            coverage.append(dict(month=day,factor=f,**counts,
                                 scored_kr=sum(k[0]=='KR' and s[f] is not None for k,s in scores.items()),
                                 scored_us=sum(k[0]=='US' and s[f] is not None for k,s in scores.items())))
    a.out.mkdir(parents=True,exist_ok=True)
    dump(a.out/'coverage.csv',coverage)
    dump(a.out/'selection_evidence.csv',evidence)
    rows,orders=[],[]
    for spans in (12,24):
        for i,day in enumerate(dates):
            if day<a.start or i+spans>=len(dates):
                continue
            if any(value is None for j in range(i,i+spans,3) for value in targets[dates[j]].values()):
                continue
            group=[simulate(s,i,spans,panel,dates,targets,a.fee,orders) for s in ('hold',*FACTORS)]
            for r in group:
                r['paired_vs_hold']=r['net']-group[0]['net']
            rows.extend(group)
    if not rows:
        raise SystemExit('No common eligible start-months. Inspect coverage.csv.')
    dump(a.out/'cohorts.csv',rows)
    dump(a.out/'orders.csv',orders)
    summary=[]
    for h in (12,24):
        for s in ('hold',*FACTORS):
            subset=[r for r in rows if r['months']==h and r['strategy']==s]
            if subset:
                summary.append(dict(months=h,strategy=s,n=len(subset),net=median(r['net'] for r in subset),
                    delta=median(r['paired_vs_hold'] for r in subset),drawdown=median(r['monthly_drawdown'] for r in subset),
                    targets=sum(r['target'] for r in subset)))
    dump(a.out/'summary.csv',summary)


if __name__=='__main__':
    main()
