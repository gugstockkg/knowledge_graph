"""Rebuild historical Korean month-end KRX price snapshots and delisting flags.

The pinned FinanceData mirror is a secondary source. Its exchange-change ratios
measure price returns and provide no terminal settlement or cash dividends.
"""
import argparse
import csv
import hashlib
import json
import re
import urllib.request
from collections import Counter
from pathlib import Path

import duckdb

MARCAP = "https://raw.githubusercontent.com/FinanceData/marcap/ad832658580379c20b8f605797afb10ecfcc690f/data"
DELIST = ("https://raw.githubusercontent.com/FinanceData/fdr_krx_data_cache/"
          "259713bf397e5e28fb0da531a19b78a3ca15766b/data/listing/delisting/2026-11-28.csv")
CODE = re.compile(r"[0-9]{5}0")
FIELDS = ["month", "market", "security", "issuer", "market_cap", "local_return",
          "krw_return", "terminal", "eligible"]


def download(url, path):
    if path.exists():
        return
    temp = path.with_suffix(path.suffix + ".part")
    with urllib.request.urlopen(url, timeout=75) as src, temp.open("wb") as dst:
        while chunk := src.read(1024 * 1024):
            dst.write(chunk)
    temp.replace(path)


def checksum(path):
    digest = hashlib.sha256()
    with path.open("rb") as f:
        while block := f.read(1024 * 1024):
            digest.update(block)
    return digest.hexdigest()


def delistings(path):
    with path.open(encoding="utf-8-sig", newline="") as file:
        return {
            (r["DelistingDate"][:7], r["Symbol"]): r
            for r in csv.DictReader(file)
            if r["Market"] in {"KOSPI", "KOSDAQ", "KOSDAQ GLOBAL"}
            and r["SecuGroup"] == "주권" and r["Kind"] == "보통주"
            and re.fullmatch(r"\d{4}-\d{2}-\d{2}", r["DelistingDate"])
            and CODE.fullmatch(r["Symbol"])
        }


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--raw", type=Path, required=True)
    p.add_argument("--out", type=Path, required=True)
    p.add_argument("--start", default="2020-01-01", help="Include warmup months")
    p.add_argument("--end", default="2026-11-26")
    p.add_argument("--cache-only", action="store_true")
    a = p.parse_args()
    a.raw.mkdir(parents=True, exist_ok=True)
    a.out.mkdir(parents=True, exist_ok=True)
    files = [a.raw / f"marcap-{y}.parquet" for y in range(int(a.start[:4]), int(a.end[:4])+1)]
    delist_path = a.raw / "kr-delisting.csv"
    sources = {f: f"{MARCAP}/{f.name}" for f in files} | {delist_path: DELIST}
    if not a.cache_only:
        for f, url in sources.items():
            download(url, f)
    events = delistings(delist_path)
    events = {k: v for k, v in events.items() if a.start <= v["DelistingDate"] <= a.end}
    con = duckdb.connect()
    con.execute("SET threads=2")
    template = """
        WITH daily AS (
          SELECT strftime(Date, '%Y-%m') AS month, Code AS security, Date,
                 Marcap AS cap, ChangesRatio / 100 AS r, coalesce(Volume, 0) AS volume
          FROM read_parquet(?, union_by_name=true)
          WHERE Date::DATE BETWEEN ?::DATE AND ?::DATE AND
          MarketId IN ('STK','KSQ') AND regexp_full_match(Code,'[0-9]{5}0')
        ), market_ends AS (
          SELECT month, max(Date) AS market_date FROM daily GROUP BY month
        ), monthly AS (
          SELECT month, security, arg_max(cap, Date) AS cap, max(Date) AS observed_date,
                 max(CASE WHEN coalesce(r,0)<=-1 THEN 1 ELSE 0 END) AS complete_loss,
                 sum(ln(CASE WHEN r > -1 THEN 1+r ELSE 1 END)) AS log_growth,
                 arg_max(volume, Date) AS closing_volume, count(r) AS observations
          FROM daily GROUP BY month, security
        )
        SELECT month, security, cap, observed_date = market_date, closing_volume, observations,
               CASE WHEN complete_loss = 1 THEN -1 ELSE exp(log_growth)-1 END AS price_return
        FROM monthly JOIN market_ends USING(month)
        ORDER BY month, security
    """
    coverage = Counter()
    observed = set()
    with (a.out/"kr_market_monthly.csv").open("w", newline="") as out:
        wr = csv.DictWriter(out, FIELDS)
        wr.writeheader()
        stream = con.execute(template, [[str(f) for f in files], a.start, a.end])
        while chunk := stream.fetchmany(10000):
            for month, symbol, cap, on_end, closing_volume, obs, price_ret in chunk:
                key = month, symbol
                observed.add(key)
                coverage[month] += 1
                terminal = int(key in events)
                valid = bool(obs and price_ret is not None) and not terminal
                wr.writerow(dict(month=month, market="KR", security=symbol, issuer=symbol,
                                 market_cap=cap or "", local_return=price_ret if valid else "",
                                 krw_return=price_ret if valid else "", terminal=terminal,
                                 eligible=int(bool(on_end and closing_volume and cap and cap>0 and not terminal))))
        for month, symbol in sorted(events.keys() - observed):
            wr.writerow(dict(month=month, market="KR", security=symbol, issuer=symbol, market_cap="",
                             local_return="", krw_return="", terminal=1, eligible=0))
    with (a.out/"kr_delistings.csv").open("w", newline="") as out:
        wr = csv.DictWriter(out, ["month", "security", "delisted", "reason", "price_row_in_month", "settlement_verified"])
        wr.writeheader()
        for (month, symbol), row in sorted(events.items()):
            wr.writerow(dict(month=month, security=symbol, delisted=row["DelistingDate"], reason=row["Reason"],
                             price_row_in_month=int((month,symbol) in observed), settlement_verified=0))
    manifest = {
        "cutoff": a.end, "start": a.start, "price_return_only": True,
        "symbol_filter": "MarketId STK/KSQ with six numeric digits ending 0; subtype proxy",
        "unknown_delisting_payoffs": len(events), "delisted_with_monthly_price_row": len(events.keys() & observed),
        "monthly_observations": dict(sorted(coverage.items())),
        "sources": [{"path": f.name, "url": url, "sha256": checksum(f)}
                    for f, url in sources.items()],
    }
    (a.out/"kr_market_manifest.json").write_text(json.dumps(manifest, indent=2)+"\n")


if __name__ == "__main__":
    main()
