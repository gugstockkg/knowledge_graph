"""Evaluate Korean historical-universe momentum under explicit delisting scenarios."""

import argparse
import csv
import math
from collections import defaultdict
from pathlib import Path
from statistics import median

from run_factor_backtest import dump

STRATEGIES = ("hold", "equal_quarterly", "momentum")
TERMINAL_RECOVERY = (0.0, 0.5, 1.0)


def read_panel(path):
    panel = defaultdict(dict)
    with path.open(newline="", encoding="utf-8") as data:
        for row in csv.DictReader(data):
            code, month = row["security"], row["month"]
            if code in panel[month]:
                raise ValueError(f"Duplicate security-month: {code}, {month}")
            terminal = row["terminal"] == "1"
            tradeable = row["eligible"] == "1"
            change = float(row["local_return"]) if row["local_return"] else None
            if (change is not None and (not math.isfinite(change) or change < -1)
                    or terminal and (change is not None or tradeable)):
                raise ValueError(f"Invalid market row: {row}")
            panel[month][code] = (change, terminal, tradeable)
    return panel


def months_apart(a, b):
    year_a, month_a = map(int, a.split("-"))
    year_b, month_b = map(int, b.split("-"))
    return 12 * (year_b - year_a) + month_b - month_a


def form_universe(panel, dates, i):
    """Rank using 11 price returns up to t−2 before trading at the t close."""
    history = [panel[m] for m in dates[i - 12:i - 1]]
    scores = []
    for code, (_, _, tradeable) in panel[dates[i]].items():
        if not tradeable:
            continue
        returns = [rows.get(code, (None, False, False))[0] for rows in history]
        if None in returns:
            continue
        scores.append((math.prod(1 + r for r in returns) - 1, code))
    scores.sort(key=lambda pair: (-pair[0], pair[1]))
    eligible = tuple(code for _, code in scores)
    return eligible, eligible[:math.ceil(0.3 * len(eligible))]


def trade(held, cash, selected, observed, fee):
    # Keep frozen positions at their carried values outside the tradeable sleeve.
    positions = {k: v for k, v in held.items()
                 if observed.get(k, (None, False, False))[2]}
    frozen = {k: v for k, v in held.items() if k not in positions}
    tradable_nav = cash + sum(positions.values())
    names = sorted(set(positions) | set(selected))
    selected_set = set(selected)
    budget = tradable_nav
    for _ in range(10):
        per_name = budget / len(selected)
        turnover = sum(abs((per_name if k in selected_set else 0) - positions.get(k, 0))
                       for k in names)
        budget = tradable_nav - turnover * fee
    return {**frozen, **dict.fromkeys(selected, budget / len(selected))}, 0.


def simulate(panel, dates, universe, i, span, strategy, recovery, fee):
    start = dates[i]
    held, cash = {}, 1.
    peak, mdd = 1., 0.
    terminal_events, stale_months = 0, 0
    for j in range(i, i + span + 1):
        month = dates[j]
        observed = panel[month]
        if j > i:
            for code, value in list(held.items()):
                change, terminal, _ = observed.get(code, (None, False, False))
                if terminal:
                    cash += recovery * value
                    del held[code]
                    terminal_events += 1
                elif change is None:
                    stale_months += 1
                else:
                    held[code] *= 1 + change

        if j == i or j < i + span and strategy != "hold" and (j - i) % 3 == 0:
            broad, top = universe[month]
            selected = top if strategy == "momentum" else broad
            held, cash = trade(held, cash, selected, observed, fee)

        frozen_end = 0.
        if j == i + span:
            for code, value in held.items():
                if observed.get(code, (None, False, False))[2]:
                    cash += value * (1 - fee)
                else:
                    frozen_end += value
            nav = cash + frozen_end
        else:
            nav = cash + sum(held.values())
        peak = max(peak, nav)
        mdd = min(mdd, nav / peak - 1)

    return dict(start=start, end=dates[i+span], months=span, strategy=strategy,
                terminal_recovery=recovery, net=nav-1, mdd=mdd, terminal_events=terminal_events,
                stale_security_months=stale_months, frozen_end=frozen_end, target=int(nav >= 1.15))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--start", default="2021-11")
    parser.add_argument("--end", default="2026-10")
    parser.add_argument("--fee", type=float, default=.001)
    args = parser.parse_args()
    if not 0 <= args.fee <= .02:
        parser.error("fee must be between 0 and .02")
    panel = read_panel(args.input)
    dates = sorted(m for m in panel if m <= args.end)
    if dates[-1] != args.end or any(months_apart(a, b) != 1 for a,b in zip(dates, dates[1:])):
        raise ValueError("Panel must contain all calendar months through the end")
    universe = {month:form_universe(panel, dates, i) for i, month in enumerate(dates)
                if i >= 12 and month >= args.start}
    if args.start not in universe or min(len(e) for e, _ in universe.values()) < 10:
        raise ValueError("Insufficient monthly eligible universe")
    rows, summary = [], []
    for span in (12, 24):
        for recovery in TERMINAL_RECOVERY:
            trials = defaultdict(list)
            for i, month in enumerate(dates[:-span]):
                if month not in universe:
                    continue
                group = [simulate(panel, dates, universe, i, span, s, recovery, args.fee)
                         for s in STRATEGIES]
                for row in group:
                    row["vs_hold"] = row["net"] - group[0]["net"]
                    row["vs_equal_quarterly"] = row["net"] - group[1]["net"]
                    rows.append(row)
                    trials[row["strategy"]].append(row)
            for strategy, subset in trials.items():
                summary.append(dict(months=span, strategy=strategy, terminal_recovery=recovery,
                    cohorts=len(subset), median_net=median(r["net"] for r in subset),
                    median_mdd=median(r["mdd"] for r in subset),
                    median_vs_hold=median(r["vs_hold"] for r in subset),
                    median_vs_equal_quarterly=median(r["vs_equal_quarterly"] for r in subset),
                    beat_hold=sum(r["vs_hold"] > 0 for r in subset),
                    targets=sum(r["target"] for r in subset),
                    terminal_events=sum(r["terminal_events"] for r in subset),
                    stale_security_months=sum(r["stale_security_months"] for r in subset),
                    median_frozen_end=median(r["frozen_end"] for r in subset)))
    args.out.mkdir(parents=True, exist_ok=True)
    dump(args.out / "kr_factor_sensitivity.csv", summary)
    dump(args.out / "kr_factor_cohorts.csv", rows)
    dump(args.out / "kr_factor_coverage.csv", [
        dict(month=m, eligible=len(e), momentum_selected=len(t),
             flagged_delistings=sum(row[1] for row in panel[m].values()))
        for m, (e, t) in universe.items()])


if __name__ == "__main__":
    main()
