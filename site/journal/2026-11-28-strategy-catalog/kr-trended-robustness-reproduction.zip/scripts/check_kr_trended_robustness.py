"""Verify matching and orders and regenerate compact diagnostics from EC2 outputs."""

import argparse
import csv
from collections import Counter, defaultdict
from pathlib import Path
from statistics import median


CALIPERS = {'momentum': .10, 'size': .15, 'liquidity': .15}
PERIODS = [('independent','2018-11','2021-10'), ('original','2021-11','2026-09')]
COMPARISONS = [('trend','hold'), ('trend','simple'), ('size_liquidity_trend','size_liquidity_control')]


def read(path):
    with path.open(encoding='utf-8-sig',newline='') as file:
        yield from csv.DictReader(file)


def write(path,rows):
    if not rows:
        raise ValueError(f'No evidence available for {path}')
    with path.open('w',encoding='utf-8',newline='') as file:
        writer=csv.DictWriter(file,list(rows[0]),lineterminator='\n')
        writer.writeheader()
        writer.writerows(rows)


def matching_stats(path):
    coverage=list(read(path/'monthly_coverage.csv'))
    evidence=list(read(path/'pairs.csv'))
    exact=[r for r in evidence if r['design']=='exact']
    keys={(r['month'],r['control']) for r in exact}
    if len(keys)!=len(exact) or any(not r['trend_sector'] or r['trend_sector']!=r['control_sector']
                                or any(float(r[f'{k}_percentile_diff'])>t for k,t in CALIPERS.items())
                                for r in exact):
        raise ValueError(f'Exact sector match does not reconcile: {path}')
    for label,begin,end in PERIODS:
        for design in ('exact','size_liquidity'):
            c=[r for r in coverage if begin<=r['month']<=end and r['design']==design]
            if not c:
                continue
            nonempty=[r for r in c if int(r['matched'])>0]
            count=Counter(r['trend_sector'] for r in evidence
                          if r['design']==design and begin<=r['month']<=end and r['trend_sector'])
            top,sector_count=count.most_common(1)[0] if count else ('',0)
            n=[int(r['matched']) for r in c]
            row=dict(run=path.name,period=label,design=design,signal_months=len(c),
                     paired_months=len(nonempty),min_pairs=min(n),median_pairs=median(n),max_pairs=max(n),
                     months_with_ge20=sum(q>=20 for q in n),
                     median_match_share=median(int(r['matched'])/int(r['trended']) for r in nonempty) if nonempty else None)
            for field in ('momentum','size','liquidity'):
                for stage in ('before','after'):
                    key=f'{field}_smd_{stage}'
                    values=[abs(float(r[key])) for r in nonempty if r[key]]
                    row[f'median_abs_{key}']=median(values) if values else None
            row.update(top_sector=top,top_sector_share=sector_count/sum(count.values()) if count else None)
            yield row


def order_counts(path):
    counts=Counter()
    for r in read(path/'orders.csv'):
        if r['event'] in ('buy','sell'):
            if not r['date'] or r['date'][:7]!=r['month'] or float(r['close_krw'])<=0:
                raise ValueError(f'Missing valid session or closing quote: {r}')
        elif r['close_krw'] or float(r['order_krw'])!=0:
            raise ValueError(f'Mark/settlement contains an order or quote: {r}')
        counts[r['event']]+=1
    return counts


def regime_sensitivity(cohorts,kospi):
    close={}
    for r in sorted(read(kospi),key=lambda a:a['date']):
        close[r['date'][:7]]=float(r['close'])
    values=defaultdict(list)
    for r in read(cohorts):
        begin,end=r['start'],r['end']
        if begin not in close or end not in close:
            continue
        result=close[end]/close[begin]-1
        regime='up' if result>=.10 else 'down' if result<=-.10 else 'sideways'
        for strategy,base in COMPARISONS:
            net,comparison=r.get(strategy+'_net',''),r.get(base+'_net','')
            if net and comparison:
                values[r['phase'],int(r['months']),regime,strategy,base].append(float(net)-float(comparison))
    return [dict(phase=phase,months=horizon,realized_regime=regime,strategy=strategy,comparator=base,
                 n=len(group),median_delta=median(group),wins=sum(x>0 for x in group))
            for (phase,horizon,regime,strategy,base),group in sorted(values.items())]


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--run',type=Path,action='append',required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--kospi',type=Path)
    args=p.parse_args()
    args.output.mkdir(parents=True,exist_ok=True)
    write(args.output/'coverage-aggregate.csv',[r for d in args.run for r in matching_stats(d)])
    for d in args.run:
        print(d.name,dict(order_counts(d)))
    if args.kospi:
        write(args.output/'kospi-sensitivity.csv',regime_sensitivity(args.run[0]/'cohorts.csv',args.kospi))


if __name__=='__main__':
    main()
