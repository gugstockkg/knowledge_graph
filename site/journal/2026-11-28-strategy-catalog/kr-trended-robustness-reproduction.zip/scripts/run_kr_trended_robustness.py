"""Audit Korean trended momentum with dated industry and matched pre-trade exposures."""

import argparse
import csv
import math
from bisect import bisect_left
from collections import defaultdict
from datetime import date
from pathlib import Path
from statistics import mean, median, pvariance

import duckdb

from kr_factor_extension import months_apart, read_panel, trade
from run_factor_backtest import dump
from run_kr_trended_momentum import form_ranks, trend_scores


CALIPERS = (.10, .15, .15)
STARTING_KRW = 1_000_000


def month_before(month, gap):
    y, m = map(int, month.split('-'))
    y, m = divmod(12*y+m-1-gap, 12)
    return f'{y:04d}-{m+1:02d}'


def load_sectors(path):
    by_security = defaultdict(dict)
    if path is None:
        return {}
    with path.open(encoding='utf-8-sig', newline='') as f:
        rows = csv.DictReader(f)
        for row in rows:
            security = row['security'].strip().zfill(6)
            sector = row['sector'].strip()
            available = row['available_date'].strip()
            date.fromisoformat(available)
            source = row['source'].strip()
            if not sector or not source:
                continue
            value = (sector, available, source, row.get('valid_to','').strip(), row.get('vintage_name','').strip())
            if available in by_security[security] and by_security[security][available] != value:
                raise ValueError(f'Conflicting sector observations: {security} {available}')
            by_security[security][available] = value
    return {code:(sorted(rows),rows) for code,rows in by_security.items()}


def sector_at(sectors, code, cutoff, max_age, historical_name=''):
    record = sectors.get(code)
    if not record:
        return None
    dates, snapshots = record
    i = bisect_left(dates, cutoff+'-01')-1
    if i < 0:
        return None
    sector, known, source, end, vintage_name = snapshots[dates[i]]
    if months_apart(known[:7],cutoff) > max_age or end and end < cutoff+'-01':
        return None
    if vintage_name and historical_name and ''.join(vintage_name.split()) != ''.join(historical_name.split()):
        return None
    return sector, known, source


def load_daily(files, begin, end):
    # Require the size observation on the market's last session of month t−2.
    # Use positive-trading days in t−4 … t−2 for median daily amount (explicit zero
    # days remain visible in the eligibility panel).
    with duckdb.connect() as db:
        db.execute("SET threads=2")
        db.execute("""
            CREATE TEMP TABLE daily AS
            SELECT Code AS security, Date::DATE AS session,
                   date_trunc('month',Date)::DATE AS month,
                   Name AS name, Marcap::DOUBLE AS cap, Close::DOUBLE AS price,
                   Volume::DOUBLE AS volume,
                   coalesce(Amount,0)::DOUBLE AS amount
            FROM read_parquet(?,union_by_name=true)
            WHERE Date::DATE >= ?::DATE AND Date::DATE < ?::DATE
             AND MarketId IN ('STK','KSQ') AND regexp_full_match(Code,'[0-9]{5}0')
        """, [[str(f) for f in files],month_before(begin,4)+'-01',month_before(end,-1)+'-01'])
        marks = db.execute("""
            WITH calendar AS (SELECT month,max(session) AS market_date FROM daily GROUP BY month),
            close AS (
             SELECT security,month,arg_max(name,session) AS name,
                    arg_max(cap,session) AS cap,arg_max(price,session) AS price,
                    max(session) AS day
             FROM daily GROUP BY security,month
            )
            SELECT strftime(c.month,'%Y-%m'),security,name,cap,price,day::VARCHAR
            FROM close c JOIN calendar d USING(month) WHERE day=market_date
        """).fetchall()
        liquidity = db.execute("""
            WITH anchors AS (SELECT DISTINCT month AS anchor FROM daily)
            SELECT strftime(anchor,'%Y-%m'),security, median(amount), count(*)
            FROM anchors JOIN daily ON daily.month BETWEEN anchor-INTERVAL '2 months' AND anchor
            WHERE amount>0
            GROUP BY anchor,security HAVING count(*)>=20
        """).fetchall()
    quotes = {(m,c):(name, cap,price,day) for m,c,name,cap,price,day in marks}
    amounts = {(m,c):amount for m,c,amount,_ in liquidity}
    return quotes,amounts


def rank_percentiles(scores):
    ordered = sorted(scores,key=lambda c:(scores[c],c))
    return {c:i/max(1,len(ordered)-1) for i,c in enumerate(ordered)}


def smd(first, second):
    scale = math.sqrt((pvariance(first)+pvariance(second))/2)
    diff = mean(first)-mean(second)
    return diff/scale if scale else 0. if diff==0 else None


def relax_pairs(base, broad, trended, past, aux, dimensions):
    # Start from the feasible exact assignment and improve each control under
    # looser constraints, retaining a unique control for every same trend pick.
    pool=[c for c in broad[:math.ceil(len(broad)/5)] if c in aux]
    ranks=[rank_percentiles({c:(past[c],*aux[c][:2])[i] for c in pool}) for i in range(3)]
    used={b for _,b,*_ in base}
    forbidden=set(trended)
    out=[]
    for a,old,*_ in base:
        used.remove(old)
        options=[]
        for b in pool:
            if b in used or b in forbidden:
                continue
            distances=[abs(rank[a]-rank[b]) for rank in ranks]
            if all(distances[i]<=CALIPERS[i] for i in range(dimensions)):
                cost=sum((distances[i]/CALIPERS[i])**2 for i in range(dimensions))
                options.append((cost,b,*distances))
        _,b,*distances=min(options)
        out.append((a,b,*distances))
        used.add(b)
    return out


def match_signals(broad,trended,past,aux,exact):
    winners = broad[:math.ceil(len(broad)/5)]
    measured = {code:aux[code] for code in winners if code in aux}
    ranks = {}
    for i in range(3):
        ranks[i] = rank_percentiles({c:((past[c],*values[:2])[i]) for c,values in measured.items()})
    controls = set(measured)-set(trended)
    choices = {}
    for a in sorted(set(trended) & set(measured)):
        links = []
        for b in controls:
            if exact and measured[a][2][0] != measured[b][2][0]:
                continue
            delta = [abs(ranks[i][a]-ranks[i][b]) for i in range(3)]
            if all(d<=c for d,c in zip(delta,CALIPERS)):
                links.append((sum((d/c)**2 for d,c in zip(delta,CALIPERS)),b,*delta))
        choices[a] = sorted(links)
    pairs=[]
    for a in sorted(choices,key=lambda x:(len(choices[x]),x)):
        for cost,b,*delta in choices[a]:
            if b in controls:
                pairs.append((a,b,*delta))
                controls.remove(b)
                break
    raw=lambda code:(past[code],*measured[code][:2])
    xs=sorted(set(trended)&set(measured))
    ys=sorted(set(measured)-set(trended))
    before=[smd([raw(c)[i] for c in xs],[raw(c)[i] for c in ys]) if xs and ys else None for i in range(3)]
    after=[smd([raw(p[0])[i] for p in pairs],[raw(p[1])[i] for p in pairs]) if pairs else None for i in range(3)]
    return pairs, len(xs),before,after


def run_account(panel, dates, start, horizon, targets, labels, quotes, events, recovery, fee, ledger, signals):
    held,cash={},1.
    peak,mdd=1.,0.
    start_month=dates[start]
    end=dates[start+horizon]
    frozen_end=0.
    writer=ledger.get(labels)
    def emit(month,code,kind,reason,signed,charged=0.,mark_before=0.,cash_credit=0.):
        if writer is None:
            return
        quote = quotes.get((month,code),('',None,None,''))
        name,_,price,session=quote
        if not name:
            prior=[quotes.get((month_before(month,i),code),('',None,None,''))[0] for i in range(1,13)]
            name=next((value for value in prior if value),'')
        score=signals.get((month,code),('', '', ''))
        if kind=='recovery':
            session=events.get((month,code),'')
            price=None
        if kind=='stale_mark':
            session=''
            price=None
        writer.writerow(dict(strategy=labels,entry=start_month,maturity=end,months=horizon,
              month=month,date=session,code=code,company=name,event=kind,reason=reason,
              close_krw=price,order_krw=signed*STARTING_KRW,fee_krw=charged*STARTING_KRW,
              pre_trade_mark_krw=mark_before*STARTING_KRW,cash_credit_krw=cash_credit*STARTING_KRW,
              lookback_last_month=month_before(month,2) if reason!='scheduled_maturity' else '',
              formation_return=score[0],r2=score[1],full_universe_return_rank=score[2],
              selected_target=int(code in targets.get(month,())) if kind in ('buy','sell') and reason!='scheduled_maturity' else ''))
    for i in range(start,start+horizon+1):
        month=dates[i]
        observed=panel[month]
        if i>start:
            for code,v in sorted(held.items()):
                change,terminal,_=observed.get(code,(None,False,False))
                if terminal:
                    settle=recovery*v
                    cash+=settle
                    del held[code]
                    emit(month,code,'recovery','delisting_recovery_scenario',0.,mark_before=v,cash_credit=settle)
                elif change is not None:
                    held[code]*=1+change
        if i==start or (i<start+horizon and (i-start)%3==0 and not labels.endswith('hold')):
            selected=targets[month]
            before=held.copy()
            held,cash=trade(held,cash,selected,observed,fee)
            selected=set(selected)
            for code in sorted(set(before)|set(held)):
                prev=before.get(code,0.)
                change=held.get(code,0.)-prev
                if abs(change)<1e-13:
                    continue
                if change>0:
                    reason='initial_selection' if i==start else 'new_selection' if not prev else 'rebalance_increase'
                else:
                    reason='left_selection' if code not in selected else 'rebalance_reduce'
                emit(month,code,'buy' if change>0 else 'sell',reason,change,abs(change)*fee,prev)
        if i==start+horizon:
            for code,v in sorted(held.items()):
                if observed.get(code,(None,False,False))[2]:
                    cash+=v*(1-fee)
                    emit(month,code,'sell','scheduled_maturity',-v,v*fee,v)
                else:
                    frozen_end+=v
                    emit(month,code,'stale_mark','not_tradeable_at_maturity',0.,mark_before=v)
            nav=cash+frozen_end
        else:
            nav=cash+sum(held.values())
        peak=max(peak,nav)
        mdd=min(mdd,nav/peak-1)
    return dict(net=nav-1,mdd=mdd,frozen_end=frozen_end)


def load_series(file):
    if file is None:
        return {}
    with file.open(encoding='utf-8-sig',newline='') as f:
        return {r['month']:float(r['close']) for r in csv.DictReader(f)}


def regime(result, threshold):
    if result is None:
        return 'unavailable'
    return 'up' if result>=threshold else 'down' if result<=-threshold else 'sideways'


def windows(panel,dates,target,quotes,events,benchmark,args,signals):
    out=[]
    fields=['strategy','entry','maturity','months','month','date','code','company','event','reason',
            'close_krw','order_krw','fee_krw','pre_trade_mark_krw','cash_credit_krw',
            'lookback_last_month','formation_return','r2','full_universe_return_rank','selected_target']
    with (args.out/'orders.csv').open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fields,lineterminator='\n')
        w.writeheader()
        for n in (12,24):
            for i,month in enumerate(dates[:-n]):
                end=dates[i+n]
                if month not in target['hold']:
                    continue
                if end<args.original_start:
                    phase='pre_2021_holdout'
                elif month>=args.original_start and end<=args.original_end:
                    phase='original_overlap'
                elif month>args.original_end:
                    phase='forward_holdout'
                else:
                    continue
                rew=[dates[j] for j in range(i,i+n,3)]
                indexed=(benchmark[end]/benchmark[month]-1 if end in benchmark and month in benchmark else None)
                trailing_dates=(month_before(month,13),month_before(month,1))
                trailing=(benchmark[trailing_dates[1]]/benchmark[trailing_dates[0]]-1 if
                          all(d in benchmark for d in trailing_dates) else None)
                row=dict(phase=phase,months=n,start=month,end=end,index_return=indexed,
                         realized_regime=regime(indexed,args.regime_threshold),
                         entry_regime=regime(trailing,args.regime_threshold))
                for name,positions in target.items():
                    if any(d not in positions for d in (rew if name!='hold' else [month])):
                        continue
                    detail={} if args.ledger_cohort and month not in args.ledger_cohort else {name:w}
                    # The broad buy-and-hold is a comparison portfolio rather than the
                    # mechanism ledger. Its thousands of positions can be regenerated.
                    if name.endswith('hold'):
                        detail={}
                    for k,v in run_account(panel,dates,i,n,positions,name,quotes,events,args.recovery,args.fee,detail,signals).items():
                        row[name+'_'+k]=v
                out.append(row)
    return out


def case_orders(args, windows_, pairs_log):
    picked=[]
    for basis in ('entry','realized'):
        for label in ('up','down'):
            candidates=[r for r in windows_ if r['phase']=='pre_2021_holdout' and r['months']==12
                        and r[basis+'_regime']==label and (not args.ledger_cohort or r['start'] in args.ledger_cohort)]
            if candidates:
                preferred=[row for row in candidates if 'exact_trend_net' in row]
                row=max(preferred or candidates,key=lambda x:x['start'])
                picked.append((basis,label,row,'exact_trend' if preferred else 'trend'))
    keys={(row['start'],strategy) for _,_,row,strategy in picked}
    by_cohort=defaultdict(lambda:defaultdict(list))
    with (args.out/'orders.csv').open(encoding='utf-8', newline='') as f:
        for r in csv.DictReader(f):
            key=r['entry'],r['strategy']
            if r['months']!='12' or key not in keys:
                continue
            by_cohort[key][r['code']].append(r)
    out=[]
    by_pair={(r['month'],r['trend']):r for r in pairs_log if r['design']=='exact'}
    for basis,label,window,strategy in picked:
        cohort=window['start']
        candidates=[]
        for code, orders in by_cohort[cohort,strategy].items():
            purchase=next((r for r in orders if r['event']=='buy' and r['reason'] in ('initial_selection','new_selection')),None)
            if purchase:
                sale=next((r for r in orders if r['reason']=='left_selection' and r['date']>purchase['date']),None)
                if sale:
                    candidates.append((purchase['date'],code,purchase,sale))
        for _,_,purchase,sale in sorted(candidates)[:2]:
            for r in (purchase,sale):
                pair=by_pair.get((r['month'],r['code']),{}) if strategy=='exact_trend' else {}
                out.append(dict(case_basis=basis,case_regime=label,entry_regime=window['entry_regime'],realized_regime=window['realized_regime'],
                                index_return=window['index_return'],trend_net=window.get(strategy+'_net'),
                                exact_control_net=window.get('exact_control_net') if strategy=='exact_trend' else None,
                                buy_hold_net=window.get('hold_net'),simple_net=window.get('simple_net'),
                                matched_control=pair.get('control',''),matched_r2=pair.get('control_r2',''),
                                industry=pair.get('trend_sector',''),sector_available=pair.get('trend_sector_available',''),
                                **r))
    return out


def summarize(rows,strategies):
    groups=defaultdict(list)
    for row in rows:
        for kind,label in (('all','all'),('realized',row['realized_regime']),('entry',row['entry_regime'])):
            groups[row['phase'],row['months'],kind,label].append(row)
    out=[]
    for (phase,h,kind,label),group in sorted(groups.items()):
        for strategy,base in strategies:
            use=[r for r in group if strategy+'_net' in r and base+'_net' in r]
            if use:
                delta=[r[strategy+'_net']-r[base+'_net'] for r in use]
                out.append(dict(phase=phase,months=h,regime_type=kind,regime=label,strategy=strategy,
                                comparator=base,windows=len(use),first=use[0]['start'],last=use[-1]['start'],
                                median_net=median(r[strategy+'_net'] for r in use),
                                median_mdd=median(r[strategy+'_mdd'] for r in use),
                                median_delta=median(delta),wins=sum(x>1e-12 for x in delta)))
    return out


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for flag in ('input','raw','out'):
        p.add_argument('--'+flag,type=Path,required=True)
    p.add_argument('--sectors',type=Path)
    p.add_argument('--index',type=Path)
    p.add_argument('--delistings',type=Path)
    p.add_argument('--start',required=True)
    p.add_argument('--end',required=True)
    p.add_argument('--original-start',default='2021-11')
    p.add_argument('--original-end',default='2026-09')
    p.add_argument('--fee',type=float,default=.001)
    p.add_argument('--recovery',type=float,default=.5)
    p.add_argument('--regime-threshold',type=float,default=.10)
    p.add_argument('--sector-max-age',type=int,default=36)
    p.add_argument('--original-sector-max-age',type=int,default=120)
    p.add_argument('--min-pairs',type=int,default=20)
    p.add_argument('--ledger-cohort',action='append')
    args=p.parse_args()
    if not 0<=args.fee<=.02 or not 0<=args.recovery<=1 or not 0<args.regime_threshold<1:
        p.error('invalid fee, recovery or regime threshold')
    panel=read_panel(args.input)
    dates=sorted(m for m in panel if m<=args.end)
    if len(dates)<13 or dates[-1]!=args.end or any(months_apart(a,b)!=1 for a,b in zip(dates,dates[1:])):
        raise ValueError('missing monthly calendar or input end')
    files=sorted(args.raw.glob('marcap-*.parquet'))
    quotes,amounts=load_daily(files,args.start,args.end)
    clarity={(m,c):v for m,c,v in trend_scores(files,args.start,args.end) if v is not None and math.isfinite(v)}
    sector_data=load_sectors(args.sectors)
    events={}
    if args.delistings:
        with args.delistings.open(encoding='utf-8-sig',newline='') as f:
            events={(r['month'],r['security']):r['delisted'] for r in csv.DictReader(f)}
    args.out.mkdir(parents=True,exist_ok=True)
    benchmark=load_series(args.index)
    target={k:{} for k in ('hold','simple','trend','size_liquidity_control','size_liquidity_trend',
                             'exact_control','exact_rank_control','exact_balance_control','exact_trend','industry_hold','industry_simple','industry_trend')}
    coverage,pairs_log,signals=[],[],{}
    for i,month in enumerate(dates):
        if i<12 or month<args.start:
            continue
        broad,plain,trend,past=form_ranks(panel,dates,i,clarity)
        target['hold'][month],target['simple'][month],target['trend'][month]=broad,plain,trend
        signals.update({(month,c):(past[c],clarity[month,c],rank) for rank,c in enumerate(broad,1)})
        known=month_before(month,2)
        cutoff=month_before(month,1)
        aux={}
        for code in broad:
            quote=quotes.get((known,code))
            cap=quote[1] if quote else None
            value=amounts.get((known,code))
            if cap and cap>0 and value and value>0:
                aux[code]=(math.log(cap),math.log(value),sector_at(sector_data,code,cutoff,args.sector_max_age if month<args.original_start else args.original_sector_max_age,quote[0] or ''))
        industry=tuple(c for c in broad if c in aux and aux[c][2] is not None)
        if len(industry)>=25:
            winners=industry[:math.ceil(len(industry)/5)]
            count=math.ceil(len(winners)/5)
            industry_trend=tuple(sorted(winners,key=lambda code:(-clarity[month,code],code))[:count])
            target['industry_hold'][month]=industry
            target['industry_simple'][month]=winners[:count]
            target['industry_trend'][month]=industry_trend
        else:
            industry_trend=()
        for prefix,eligible,leaders,kind in (('size_liquidity',broad,trend,False),
                                            ('exact',industry,industry_trend,True)):
            use={c:aux[c] for c in eligible if c in aux}
            pairs,covered,before,after=match_signals(eligible,leaders,past,use,kind)
            coverage.append(dict(month=month,design=prefix,eligible=len(eligible),trended=len(leaders),
                                 feature_covered=covered,matched=len(pairs),
                                 momentum_smd_before=before[0],size_smd_before=before[1],liquidity_smd_before=before[2],
                                 momentum_smd_after=after[0],size_smd_after=after[1],liquidity_smd_after=after[2]))
            if len(pairs)<args.min_pairs:
                continue
            target[prefix+'_trend'][month]=tuple(r[0] for r in pairs)
            target[prefix+'_control'][month]=tuple(r[1] for r in pairs)
            designs=[(prefix,pairs)]
            if kind:
                for label,count in (('exact_rank',1),('exact_balance',3)):
                    adjusted=relax_pairs(pairs,eligible,leaders,past,use,count)
                    target[label+'_control'][month]=tuple(r[1] for r in adjusted)
                    designs.append((label,adjusted))
            for design,stage in designs:
                for a,b,dr,ds,dl in stage:
                    info=lambda c:use[c][2] or ('','','')
                    values=dict(month=month,design=design,trend=a,control=b,momentum_percentile_diff=dr,
                                size_percentile_diff=ds,liquidity_percentile_diff=dl)
                    for l,c in (('trend',a),('control',b)):
                        values.update({l+'_momentum':past[c],l+'_r2':clarity[month,c],
                                       l+'_market_cap':math.exp(use[c][0]),l+'_median_amount':math.exp(use[c][1]),
                                       l+'_sector':info(c)[0],l+'_sector_available':info(c)[1],l+'_sector_source':info(c)[2]})
                    pairs_log.append(values)
    out=windows(panel,dates,target,quotes,events,benchmark,args,signals)
    if not out:
        raise ValueError('no complete evaluation windows')
    # Write an explicit schema even when dated industry coverage is missing.
    allkeys=list(dict.fromkeys(k for row in out for k in row))
    dump(args.out/'cohorts.csv',[{k:r.get(k,'') for k in allkeys} for r in out])
    dump(args.out/'case_orders.csv',case_orders(args,out,pairs_log))
    dump(args.out/'monthly_coverage.csv',coverage)
    dump(args.out/'pairs.csv',pairs_log)
    pairs=[('simple','hold'),('trend','hold'),('trend','simple'),
           ('size_liquidity_trend','size_liquidity_control'),('exact_trend','exact_rank_control'),
           ('exact_trend','exact_balance_control'),('exact_trend','exact_control'),
           ('industry_simple','industry_hold'),('industry_trend','industry_hold'),
           ('industry_trend','industry_simple')]
    dump(args.out/'summary.csv',summarize(out,pairs))


if __name__=='__main__':
    main()
