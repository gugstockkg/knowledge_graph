"""Prepare the archived 2018 FinanceData sector labels and Korean regime data."""
import argparse
import csv
import gzip
import re
import urllib.request
from pathlib import Path

COMMIT = 'b87a182c25f6ae0a722111ee7eb0edab554e6d1b'
SOURCE = f'https://raw.githubusercontent.com/FinanceData/stock_master/{COMMIT}/stock_master.csv.gz'
AVAILABLE = '2018-09-30'
KOSPI_SOURCE = ('https://raw.githubusercontent.com/FinanceData/fdr_krx_data_cache/'
                '259713bf397e5e28fb0da531a19b78a3ca15766b/data/index/year_ks11')


SECTIONS = (
    ('A 농업·임업·어업', 1, 3), ('B 광업', 5, 8), ('C 제조업', 10, 34),
    ('D 전기·가스·증기·공기조절 공급업', 35, 35), ('E 수도·하수·폐기물·원료재생업', 36, 39),
    ('F 건설업', 41, 42), ('G 도매 및 소매업', 45, 47), ('H 운수 및 창고업', 49, 52),
    ('I 숙박 및 음식점업', 55, 56), ('J 정보통신업', 58, 63), ('K 금융 및 보험업', 64, 66),
    ('L 부동산업', 68, 68), ('M 전문·과학 및 기술 서비스업', 70, 73),
    ('N 사업시설관리·사업지원 및 임대 서비스업', 74, 76), ('O 공공행정·국방·사회보장행정', 84, 84),
    ('P 교육 서비스업', 85, 85), ('Q 보건업 및 사회복지 서비스업', 86, 87),
    ('R 예술·스포츠 및 여가관련 서비스업', 90, 91), ('S 협회·단체·수리 및 기타 개인 서비스업', 94, 96),
    ('T 가구 내 고용활동 및 자가소비 생산활동', 97, 98), ('U 국제 및 외국기관', 99, 99),
)


def ksic_section(code):
    if not re.fullmatch(r'[0-9]{2,5}', code):
        return ''
    division = int(code[:2])
    return next((name for name, low, high in SECTIONS if low <= division <= high), '')


def prepare(source, output, broad=False):
    if not source.is_file():
        source.parent.mkdir(parents=True, exist_ok=True)
        with urllib.request.urlopen(SOURCE, timeout=45) as response:
            source.write_bytes(response.read())
    output.parent.mkdir(parents=True, exist_ok=True)
    with gzip.open(source, 'rt', encoding='utf-8-sig', newline='') as archive, output.open(
            'w', encoding='utf-8', newline='') as stream:
        writer = csv.DictWriter(stream, ('security', 'sector', 'available_date', 'source',
                                         'vintage_name', 'vintage_market'), lineterminator='\n')
        writer.writeheader()
        seen = set()
        for row in csv.DictReader(archive):
            code = row['Symbol']
            sector = ksic_section(row['Industy_code'].strip()) if broad else row['Sector'].strip()
            market = row['Market']
            if (row['Listing'] != 'True' or market not in {'KOSPI', 'KOSDAQ', 'KODAQ'}
                    or not sector or not re.fullmatch(r'[0-9]{5}0', code)):
                continue
            if code in seen:
                raise ValueError(f'duplicate eligible vintage security: {code}')
            seen.add(code)
            writer.writerow(dict(security=code, sector=sector, available_date=AVAILABLE, source=SOURCE,
                                 vintage_name=row['Name'], vintage_market=market.replace('KODAQ','KOSDAQ')))
    if not seen:
        raise ValueError('no known industry classifications')
    return len(seen)


def kospi(output):
    cache = output.parent / 'kospi'
    cache.mkdir(parents=True, exist_ok=True)
    observations = {}
    for year in range(2016, 2027):
        path = cache / f'{year}.csv'
        if not path.is_file():
            with urllib.request.urlopen(f'{KOSPI_SOURCE}/{path.name}', timeout=45) as response:
                path.write_bytes(response.read())
        with path.open(encoding='utf-8-sig', newline='') as archive:
            for row in csv.DictReader(archive):
                date = row['Date']
                if not '2016-01-01' <= date <= '2026-11-26':
                    continue
                close = float(row['Close'])
                if date in observations or not close > 0:
                    raise ValueError(f'invalid Korean index observation: {date}')
                observations[date] = close
    with output.open('w', encoding='utf-8', newline='') as stream:
        writer = csv.writer(stream, lineterminator='\n')
        writer.writerow(('date', 'close'))
        writer.writerows(sorted(observations.items()))
    return len(observations)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--index-out', type=Path)
    parser.add_argument('--broad-out', type=Path)
    args = parser.parse_args()
    print(f'{prepare(args.source, args.out)} known listed securities in the archived vintage')
    if args.broad_out:
        print(f'{prepare(args.source, args.broad_out, broad=True)} listed securities with KSIC section')
    if args.index_out:
        print(f'{kospi(args.index_out)} trading days in the archived Korean index')
