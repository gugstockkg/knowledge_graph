"""Korean price-only Trended Momentum variant on historical KRX common-share proxies."""
import argparse
import math
from pathlib import Path
from statistics import median

import duckdb

from kr_factor_extension import months_apart, read_panel, simulate
from run_factor_backtest import dump


def trend_scores(files, start, end):
    """Use adjustment-consistent daily price levels, rebased from exchange price returns."""
    with duckdb.connect() as con:
        con.execute('SET threads=2')
        return con.execute("""
            WITH daily AS (
              SELECT Code AS security, Date::DATE AS session,
                     ChangesRatio::DOUBLE/100 AS ret, coalesce(Volume, 0) AS volume
              FROM read_parquet(?, union_by_name=true)
              WHERE MarketId IN ('STK','KSQ') AND regexp_full_match(Code,'[0-9]{5}0')
            ), mark AS (
              SELECT security, session, ret, volume,
                     exp(sum(CASE WHEN ret > -1 THEN ln(1+ret) ELSE 0 END)
                         OVER (PARTITION BY security ORDER BY session)) AS price_level
              FROM daily
            ), formation AS (
              SELECT trade_month, trade_month - INTERVAL '12 months' AS first,
                     trade_month - INTERVAL '1 month' AS stop
              FROM generate_series(?::DATE, ?::DATE, INTERVAL '1 month') AS t(trade_month)
            )
            SELECT strftime(trade_month, '%Y-%m') AS month, security,
                   regr_r2(price_level,date_diff('day',first,session))
                       FILTER (WHERE volume > 0 AND ret IS NOT NULL) AS tc
            FROM formation JOIN mark ON session >= first AND session < stop
            GROUP BY month, security
            HAVING count(ret) FILTER (WHERE volume > 0)>=200 AND count(*) FILTER (WHERE ret <= -1)=0
            """, [[str(path) for path in files], start+'-01', end+'-01']).fetchall()


def form_ranks(panel, dates, i, clarity):
    month = dates[i]
    history = [panel[m] for m in dates[i-12:i-1]]
    eligible = []
    for security, (_, _, tradeable) in panel[month].items():
        if not tradeable or (month, security) not in clarity:
            continue
        returns = [rows.get(security, (None, False, False))[0] for rows in history]
        if None in returns:
            continue
        eligible.append((math.prod(1 + r for r in returns)-1, security))
    eligible.sort(key=lambda pair: (-pair[0], pair[1]))
    if len(eligible) < 25:
        raise ValueError(f'Insufficient eligible names for nested quintiles in {month}')
    broad = tuple(code for _, code in eligible)
    winners = broad[:math.ceil(len(broad)/5)]
    size = math.ceil(len(winners)/5)
    trended = tuple(sorted(winners, key=lambda code: (-clarity[month, code], code))[:size])
    return broad, winners[:size], trended, dict((code, result) for result, code in eligible)


def run(args):
    panel = read_panel(args.input)
    dates = sorted(month for month in panel if month <= args.end)
    if not dates or dates[-1] != args.end or any(months_apart(a,b)!=1 for a,b in zip(dates,dates[1:])):
        raise ValueError('Missing monthly observation calendar')
    files = sorted(args.raw.glob('marcap-*.parquet'))
    if not files:
        raise ValueError('No archived marcap parquet inputs')
    clarity = {(month, code): value for month,code,value in trend_scores(files,args.start,args.end)
               if value is not None and math.isfinite(value)}
    ranks = {month:form_ranks(panel,dates,i,clarity)
             for i,month in enumerate(dates) if i>=12 and month>=args.start}
    if args.start not in ranks:
        raise ValueError('Missing warmup')
    pure = {month:(broad,normal) for month,(broad,normal,_,_) in ranks.items()}
    trend = {month:(broad,trended) for month,(broad,_,trended,_) in ranks.items()}
    summary, cohorts = [], []
    for span in (12,24):
        for recovery in (0.,.5,1.):
            grouped = {key:[] for key in ('hold','momentum_same_size','trended_momentum')}
            for i,month in enumerate(dates[:-span]):
                if month not in ranks:
                    continue
                hold = simulate(panel,dates,pure,i,span,'hold',recovery,args.fee)
                normal = simulate(panel,dates,pure,i,span,'momentum',recovery,args.fee)
                trended = simulate(panel,dates,trend,i,span,'momentum',recovery,args.fee)
                for name,row in zip(grouped,(hold,normal,trended)):
                    row['strategy'] = name
                    row['vs_hold'] = row['net']-hold['net']
                    row['vs_pure'] = row['net']-normal['net']
                    grouped[name].append(row)
                    cohorts.append(row)
            for strategy,group in grouped.items():
                summary.append(dict(months=span,recovery=recovery,strategy=strategy,windows=len(group),
                    median_net=median(r['net'] for r in group),median_mdd=median(r['mdd'] for r in group),
                    paired_vs_hold=median(r['vs_hold'] for r in group),paired_vs_pure=median(r['vs_pure'] for r in group),
                    wins_vs_hold=sum(r['vs_hold']>0 for r in group),wins_vs_pure=sum(r['vs_pure']>0 for r in group),
                    targets=sum(r['target'] for r in group)))
    args.out.mkdir(parents=True,exist_ok=True)
    dump(args.out/'kr_trended_momentum_summary.csv',summary)
    dump(args.out/'kr_trended_momentum_cohorts.csv',cohorts)
    dump(args.out/'kr_trended_momentum_universe.csv',[
        dict(month=month,eligible=len(broad),selected=len(trended),overlap=len(set(normal)&set(trended)))
        for month,(broad,normal,trended,_) in ranks.items()])
    selection = []
    for month, (_, normal, trended, past_returns) in ranks.items():
        normal, trended = set(normal), set(trended)
        selection.extend(dict(month=month,security=code,cumulative_return=past_returns[code],
                              tc=clarity[month,code],momentum=int(code in normal),
                              trended=int(code in trended))
                         for code in sorted(normal|trended))
    dump(args.out/'kr_trended_momentum_selection.csv',selection)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('input','raw','out'):
        parser.add_argument('--'+name, type=Path, required=True)
    parser.add_argument('--start',default='2021-11')
    parser.add_argument('--end',default='2026-10')
    parser.add_argument('--fee',type=float,default=.001)
    args = parser.parse_args()
    if not 0 <= args.fee <= .02:
        parser.error('fee must be between 0 and .02')
    run(args)
