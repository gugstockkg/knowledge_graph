# 한국 추세 일관성의 독립 기간 자료

시세는 2016년 1월부터 2026년 11월 26일까지의 FinanceData 마감 일별 원천을 사용했다. 기존 KRX 마감 패널 생성기를 같은 기준으로 다시 실행했다. 시세는 배당을 제외한 가격수익률이다. 상장폐지 자료는 확인된 폐지일을 주며 최종 지급액은 제공하지 않는다. 2016년부터 준비 데이터를 받아 2018년 독립 기간의 신호 형성에 사용하였다. [일별 시세 원천](https://github.com/FinanceData/marcap/tree/ad832658580379c20b8f605797afb10ecfcc690f/data)

업종은 2018년 9월 30일 당시 공개된 FinanceData 종목 마스터의 거래소 업종명인 `Sector`를 사용한다. 이 자료의 `Industry`는 주요 사업 설명이므로 구분하였다. 그날 당시 상장이 확인되고 업종명이 알려진 KOSPI·KOSDAQ 종목 중 보통주 숫자 코드 프록시를 만족한 2,073개 행을 보존했다. 기준일 이후의 당시 종목을 구분하는 업종 고정 판본이다. 이후 IPO의 업종과 재분류 이력은 관측 범위 밖에 있다. 당시 업종의 비교는 2018년 10월부터 가능하다. 이후 기간에서 같은 업종을 사용했다는 말은 2018년 공개 판본의 같은 업종을 뜻한다. 거래소 과거 조회는 2018년 10월, 2021년 9월, 2026년 10월 표본 요청 모두에서 `HTTP 400 LOGOUT`을 반환했다. 현재 시점 업종으로 과거 종목을 채우지 않았다. [2018년 공개 업종 파일](https://github.com/FinanceData/stock_master/blob/b87a182c25f6ae0a722111ee7eb0edab554e6d1b/stock_master.csv.gz)

업종 세분류의 짝 부족을 점검하기 위해 동일한 2018년 원본의 DART 산업코드를 다른 집계에도 사용했다. 원본 코드의 선두 0을 보존하고 앞 두 자리 중분류를 제10차 한국표준산업분류의 공식 대분류 범위에 연결했다. 2,073개 종목에서 17개 대분류가 나타났다. 제조업 1,232개가 한 대분류에 모이므로 대분류 비교를 세부 산업 일치로 해석하기 어렵다. [공식 분류 범위](https://link.mods.go.kr/upload/sbr/2023_sbr_guide.pdf)

코스피 지수의 일별 가격 종가는 같은 공급자의 고정 연도별 보관본에서 수집했다. 2016년 1월 4일부터 2026년 11월 26일까지 2,673거래일이다. 평가 종목과 독립된 지수 변화를 사용해 평가창을 분류할 수 있다. [지수 원천](https://github.com/FinanceData/fdr_krx_data_cache/tree/259713bf397e5e28fb0da531a19b78a3ca15766b/data/index/year_ks11)

## EC2 입력 파일

기준 경로는 `/var/lib/fintos-portfolio/kr-research-data/trended-momentum/pit-data`다.

| 파일 | 자료 행 | SHA-256 |
|---|---:|---|
| `stock-master-2018-09-30.csv.gz` | 3,516 | `d0a6f32e88cd3461e3cd33bedda219b7ff280b876b7c288c5ea4f5037f620d9a` |
| `kr-sector-vintage.csv` | 2,073 | `9aa805479e3a4171c9f098f936000f5ea3ea325fb00cd1d23580a763c5fa3cc9` |
| `kr-sector-broad-vintage.csv` | 2,073 | `119cf9edc309e8a5a4326c216e68d8929815fac8ecf9f8c718cb8d08fed40185` |
| `long-panel/kr_market_monthly.csv` | 302,764 | `40221ad29a8ec8d7efa58285b484899bbd0ed0df0d48e4aa17ec06d9134607a0` |
| `kr-kospi-index.csv` | 2,673 | `f98e93ab4223d93ed19d73475c0175732b66fe095ac04c67168eb480b84c361e` |

```bash
root=/var/lib/fintos-portfolio/kr-research-data
out="$root/trended-momentum/pit-data"
"$root/venv/bin/python" scripts/prepare_kr_sector_vintage.py \
  --source "$out/stock-master-2018-09-30.csv.gz" --out "$out/kr-sector-vintage.csv" \
  --index-out "$out/kr-kospi-index.csv" \
  --broad-out "$out/kr-sector-broad-vintage.csv"
"$root/venv/bin/python" scripts/kr_market_history.py \
  --raw "$root/raw" --out "$out/long-panel" --start 2016-01-01 --end 2026-11-26
```

`long-panel/kr_market_manifest.json`은 11개 연도별 가격 판본과 상장폐지 파일의 다운로드 주소 및 SHA-256을 포함한다.

EC2에서 업종과 코스피 자료를 스크립트로 다시 만들고 두 입력의 바이트 일치를 확인했다. 월별 패널은 기존 실험의 2020년 1월부터 2026년 10월까지 겹치는 202,108행에서 식별자, 시총, 표본 적격·상장폐지 플래그가 일치했고 수익률 차이는 1e-12 허용 오차 이내였다.
