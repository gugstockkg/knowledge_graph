# 한국 종목과 공시 시점 자료

## 종목군과 시세

[FinanceData/marcap](https://github.com/FinanceData/marcap/tree/ad832658580379c20b8f605797afb10ecfcc690f)의 2020~2026년 연도별 KRX 일별 내역을 EC2에 보관했다. 각 거래일에 기록된 시세와 시가총액에서 당시 종목을 복원한다. 예비 필터는 자료의 KOSPI·KOSDAQ 시장 코드와 0으로 끝나는 여섯 자리 숫자 코드다. 전체 보통주를 정확히 분류하려면 시점별 종목 종류와 종목코드 재사용·합병 연결 이력이 더 필요하다.

[FinanceData 상장폐지 스냅샷](https://github.com/FinanceData/fdr_krx_data_cache/blob/259713bf397e5e28fb0da531a19b78a3ca15766b/data/listing/delisting/2026-11-28.csv)에서 상장폐지일과 사유를 연결한다. 상장폐지 달에는 인수대금, 교부 주식, 정리매매 뒤 실제 정산금이 확인될 때까지 월 수익률을 공란으로 둔다. 월말 시세가 있고 거래가 있었던 종목에만 신규 주문 후보 자격을 부여한다. 이 자료의 거래소 일별 등락률은 가격수익률이며 배당을 포함한 총수익률이 아니다.

EC2 KRX·KIND 웹 접속 점검에서 HTTP 403을 받았다. 거래소 직접 자료는 [KRX 공식 일별매매 API](https://openapi.krx.co.kr/contents/OPP/USES/service/OPPUSES002_S2.cmd?BO_ID=JvJFzlAENzZlPBDNGAWC)의 접근 권한을 확보해 대조할 수 있다. 현재 사용한 공개 미러는 보조 출처이며, 액면분할과 배당, 상장폐지 정산을 결합한 검증은 남아 있다.

EC2 변환에서 83개월에 걸쳐 시세가 있는 종목·월 204,687행을 확보했다. 2021년 11월~2026년 11월 경계월을 포함하면 154,861행이다. 전체 수집 범위에서 예비 필터를 통과한 상장폐지 348건 중 332건은 폐지월 가격과 연결되었고, 나머지 16건은 별도의 폐지월 행으로 기록했다. 모든 폐지월의 정산 수익률은 결측이다.

## 재무제표 공개 시각

[OpenDART 재무정보 일괄다운로드](https://opendart.fss.or.kr/disclosureinfo/fnltt/dwld/main.do)는 현재 시점에 재생성되는 파일이다. 가령 조사 당시 2021 사업연도 재무상태표 ZIP의 생성 시각은 2026년 7월 8일이었다. 해당 값을 2022년 최초 제출일로 소급해 붙이면 정정 정보가 앞당겨질 수 있다.

대신 공시목록의 접수번호와 접수일을 기록하고 [접수번호별 XBRL 원본](https://opendart.fss.or.kr/guide/detail.do?apiGrpCd=DS003&apiId=2019019)을 내려받는다. 사업보고서 표제와 연말 XBRL 문맥을 일치시키고, 연결·별도 문맥을 섞지 않는다. 매출총이익 값이 비어 있으면 같은 문맥에서 매출과 매출원가가 모두 확인될 때만 계산한다. 공시별 SHA-256과 선택한 문맥은 감사 CSV에 기록한다. 접수일은 시각을 확인하지 못했으므로 당일 주문에는 쓰지 않는다. 정정 공시는 새 접수일의 새 버전으로 보존한다.

EC2에서 삼성전자 2022 사업연도 원본을 대조했다. 2023년 3월 7일 접수번호 `20230307000542`의 연결재무제표에는 지배기업 소유주 지분 345.19조 원, 자산 448.42조 원, 매출총이익 112.19조 원, 순이익 55.65조 원, 영업활동현금흐름 62.18조 원이 기록되어 있다.

## 재현

EC2 자료 작업 경로는 `/var/lib/fintos-portfolio/kr-research-data`다. 로컬 재수집에서는 같은 버전의 공개 원본과 OpenDART 키가 필요하다.

```bash
python3 -m venv .venv
.venv/bin/pip install duckdb==1.4.4
.venv/bin/python scripts/kr_market_history.py --raw data/kr --out data/kr-derived
python3 scripts/kr_dart_pit.py --raw data/kr/dart --out data/kr-derived \
  --symbol 005930=00126380 --symbol 000660=00164779 --symbol 005380=00164742
```

가격은 2020년부터 계산해 2021년 11월 진입 전 학습 기간을 둔다. 샘플 재무제표와 과거 전체 종목 시세는 범위가 다르다. 재무 신호의 미국·한국 5년 본실험에는 더 넓은 접수번호별 연간 원본과 상장폐지 정산을 확보해야 한다.
