"""Measure how rolling-window phase affects published US factor comparisons."""
import argparse
import csv
import statistics
from pathlib import Path

from french_factor_reference import FILES, acquire, metric


def audit(raw, start, end):
    source = {}
    for key, name in FILES.items():
        rows, _ = acquire(name, raw / name)
        if key == 'market':
            source[key] = {d: (v[0] + v[3]) / 100 for d, v in rows.items()
                           if min(v[0], v[3]) > -90}
        else:
            segment = slice(-10, -7) if key == 'accruals' else slice(-3, None)
            source[key] = {d: statistics.mean(v[segment]) / 100 for d, v in rows.items()
                           if min(v[segment]) > -90}
    months = sorted(d for d in set.intersection(*(set(rows) for rows in source.values()))
                    if start <= d <= end)
    serial = [int(d[:4]) * 12 + int(d[4:]) for d in months]
    if any(y - x != 1 for x, y in zip(serial, serial[1:])):
        raise ValueError('missing calendar months')
    output = []
    for horizon in (12, 24):
        windows = [months[i:i+horizon] for i in range(len(months)-horizon+1)]
        for phase in range(horizon):
            fixed = windows[phase::horizon]
            if not fixed:
                continue
            market = [metric([source['market'][m] for m in window])[0] for window in fixed]
            for key, returns in source.items():
                if key == 'market':
                    continue
                differences = [metric([returns[m] for m in window])[0] - benchmark
                               for window, benchmark in zip(fixed, market)]
                output.append(dict(months=horizon, phase=phase, first=fixed[0][0],
                                   last=fixed[-1][-1], strategy=key, windows=len(fixed),
                                   median_paired_delta=statistics.median(differences),
                                   wins=sum(d > 1e-10 for d in differences)))
    return output


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--raw', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--start', default='202112')
    parser.add_argument('--end', default='202610')
    args = parser.parse_args()
    rows = audit(args.raw, args.start, args.end)
    with args.out.open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator='\n')
        writer.writeheader()
        writer.writerows(rows)
