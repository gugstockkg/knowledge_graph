#!/usr/bin/env python3
"""Inventory public SEC listing and delisting notices without inferring a traded universe."""

import argparse
import csv
import json
import os
import re
from collections import Counter
from datetime import date
from pathlib import Path
from shutil import copyfileobj
from time import sleep
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from us_sec_fsds import fiscal_quarters, source_digest

FULL_INDEX = "https://www.sec.gov/Archives/edgar/full-index"
FORM_KINDS = {
    "8-A12B": "exchange_registration",
    "8-A12B/A": "exchange_registration_amendment",
    "25": "removal_notice",
    "25-NSE": "removal_notice",
    "25/A": "removal_notice_amendment",
    "25-NSE/A": "removal_notice_amendment",
}
PATH = re.compile(r"edgar/data/[0-9]+/([0-9]{10}-[0-9]{2}-[0-9]{6})\.txt\Z")


def index_url(quarter):
    year, number = quarter.split("q")
    return f"{FULL_INDEX}/{year}/QTR{number}/master.idx"


def download(path, quarter, agent):
    temp = path.with_suffix(".idx.part")
    try:
        req = Request(index_url(quarter), headers={"User-Agent": agent, "Accept": "text/plain"})
        with urlopen(req, timeout=100) as response, temp.open("wb") as file:
            copyfileobj(response, file)
        validate_index(temp)
        temp.replace(path)
        sleep(1)
    finally:
        temp.unlink(missing_ok=True)


def validate_index(path):
    expected = "CIK|Company Name|Form Type|Date Filed|Filename"
    with path.open(encoding="latin-1") as file:
        if not any(line.rstrip() == expected for _, line in zip(range(40), file)):
            raise ValueError(f"SEC master index header not found in {path}")


def extract(path, quarter, start, end):
    validate_index(path)
    with path.open(encoding="latin-1") as file:
        for line in file:
            pieces = line.rstrip("\r\n").rsplit("|", 3)
            if len(pieces) != 4 or pieces[1] not in FORM_KINDS:
                continue
            form, filed, relative = pieces[1:]
            cik, name = pieces[0].split("|", 1)
            filename = PATH.fullmatch(relative)
            if filename is None or not cik.isdecimal():
                raise ValueError(f"malformed SEC path or CIK in {path}: {relative}")
            filing_day = date.fromisoformat(filed)
            if start <= filing_day <= end:
                yield {"market": "US", "filed": filing_day.isoformat(), "form": form,
                       "kind": FORM_KINDS[form], "filing_index_cik": cik.zfill(10), "index_name": name,
                       "accession": filename.group(1), "source_quarter": quarter,
                       "filing_url": f"https://www.sec.gov/Archives/{relative}"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raw", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--from-quarter", default="2021q4")
    parser.add_argument("--to-quarter", default="2026q4")
    parser.add_argument("--start", type=date.fromisoformat, default=date(2021, 11, 26))
    parser.add_argument("--end", type=date.fromisoformat, default=date(2026, 11, 26))
    parser.add_argument("--user-agent", default=os.environ.get("SEC_USER_AGENT"))
    parser.add_argument("--offline", action="store_true")
    parser.add_argument("--allow-missing", action="store_true")
    args = parser.parse_args()
    if args.start > args.end:
        parser.error("the start date must not follow the end date")
    args.raw.mkdir(parents=True, exist_ok=True)
    args.out.mkdir(parents=True, exist_ok=True)
    missing, files, rows = [], [], {}
    for quarter in fiscal_quarters(args.from_quarter, args.to_quarter):
        path = args.raw / f"{quarter}.idx"
        if not path.is_file():
            if args.offline:
                missing.append(quarter)
                continue
            if not args.user_agent:
                parser.error("SEC_USER_AGENT or --user-agent must identify your organization and contact")
            try:
                download(path, quarter, args.user_agent)
            except (HTTPError, URLError, TimeoutError, ValueError) as exc:
                print(f"{quarter}: no index available: {exc}", flush=True)
                missing.append(quarter)
                continue
        for row in extract(path, quarter, args.start, args.end):
            rows[(row["filing_index_cik"], row["accession"])] = row
        files.append({"quarter": quarter, "url": index_url(quarter), "bytes": path.stat().st_size,
                      "sha256": source_digest(path)})
    if missing and not args.allow_missing:
        parser.error(f"missing quarter indexes: {', '.join(missing)}")
    if not rows:
        parser.error("no eligible notices in acquired indexes")
    records = sorted(rows.values(), key=lambda r: (r["filed"], r["filing_index_cik"], r["accession"]))
    output = args.out / "us_exchange_notices.csv"
    temp = output.with_suffix(".csv.part")
    with temp.open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=tuple(records[0]))
        writer.writeheader()
        writer.writerows(records)
    temp.replace(output)
    manifest = {"start": args.start.isoformat(), "end": args.end.isoformat(), "sources": files,
                "missing_quarters": missing, "rows": len(records),
                "forms": dict(Counter(r["form"] for r in records)),
                "scope": "SEC filing notices only; no trading times, prices, security IDs, or payouts"}
    (args.out / "us_exchange_notices_manifest.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({k: v for k, v in manifest.items() if k != "sources"}), flush=True)


if __name__ == "__main__":
    main()
