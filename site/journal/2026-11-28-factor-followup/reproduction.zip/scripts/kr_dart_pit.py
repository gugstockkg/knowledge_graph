"""Download original OpenDART XBRL by filing accession and extract annual IFRS values."""
import argparse
import calendar
import csv
import datetime as dt
import hashlib
import io
import json
import os
import re
import time
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
import zipfile
from collections import Counter, defaultdict
from decimal import Decimal, InvalidOperation
from pathlib import Path

API = "https://opendart.fss.or.kr/api/"
FIELDS = ("market", "issuer", "fiscal_end", "published", "accession", "book_equity",
          "assets", "gross_profit", "net_income", "operating_cash_flow")
TAGS = {"EquityAttributableToOwnersOfParent", "Equity", "Assets",
        "GrossProfit", "Revenue", "CostOfSales", "ProfitLoss",
        "CashFlowsFromUsedInOperatingActivities"}


def api(key, endpoint, **query):
    url = API + endpoint + "?" + urllib.parse.urlencode(dict(crtfc_key=key, **query))
    for attempt in range(3):
        try:
            with urllib.request.urlopen(url, timeout=30) as response:
                return response.read()
        except OSError as exc:
            if attempt == 2:
                raise RuntimeError(f"OpenDART {endpoint} {type(exc).__name__}, status={getattr(exc,'code',None)}") from None
            time.sleep(1 + attempt)


def cached(key, path, endpoint, **query):
    if not path.exists():
        blob = api(key, endpoint, **query)
        status = re.search(rb'<status>([0-9]+)</status>|"status"\s*:\s*"([0-9]+)"', blob[:4096])
        code = next((value for value in status.groups() if value), None) if status else None
        if code in {b"010", b"011", b"012", b"020", b"021", b"901"}:
            return blob
        partial = path.with_suffix(path.suffix + ".part")
        partial.write_bytes(blob)
        partial.replace(path)
    return path.read_bytes()


def date(value):
    return dt.date.fromisoformat(value)


def slug(element):
    return element.tag.rsplit("}", 1)[-1]


def extract(blob, fiscal_end):
    with zipfile.ZipFile(io.BytesIO(blob)) as z:
        doc = next(name for name in z.namelist() if name.lower().endswith(".xbrl"))
        root = ET.fromstring(z.read(doc))
    contexts = {}
    for e in root:
        if slug(e) != "context":
            continue
        items = defaultdict(list)
        for x in e.iter():
            items[slug(x)].append(x)
        if items["typedMember"]:
            continue
        members = [x.text.rsplit(":", 1)[-1] for x in items["explicitMember"] if x.text]
        if members == ["ConsolidatedMember"]:
            scope = "CFS"
        elif members == ["SeparateMember"]:
            scope = "OFS"
        elif not members:
            scope = "UNDIMENSIONED"
        else:
            continue
        if items["instant"] and items["instant"][0].text == fiscal_end:
            contexts[e.attrib["id"]] = scope, "instant"
        elif items["startDate"] and items["endDate"] and items["endDate"][0].text == fiscal_end:
            start = date(items["startDate"][0].text)
            if 340 <= (date(fiscal_end) - start).days <= 400:
                contexts[e.attrib["id"]] = scope, "duration"
    vals = defaultdict(lambda: defaultdict(set))
    for e in root:
        tag = slug(e)
        ctx = contexts.get(e.get("contextRef"))
        if tag not in TAGS or not ctx or e.get("unitRef") != "KRW" or not e.text:
            continue
        if (tag in {"Assets", "Equity", "EquityAttributableToOwnersOfParent"}) != (ctx[1] == "instant"):
            continue
        if "ifrs" not in e.tag.lower():
            continue
        try:
            value = Decimal(e.text.strip())
            if value.is_finite():
                vals[ctx[0]][tag].add(value)
        except InvalidOperation:
            continue
    for scope in ("CFS", "UNDIMENSIONED", "OFS"):
        if scope not in vals:
            continue
        by_tag = {tag: next(iter(v)) for tag,v in vals[scope].items() if len(v)==1}
        gross = by_tag.get("GrossProfit")
        if gross is None and {"Revenue","CostOfSales"} <= by_tag.keys():
            gross = by_tag["Revenue"] - abs(by_tag["CostOfSales"])
        result = dict(book_equity=by_tag.get("EquityAttributableToOwnersOfParent", by_tag.get("Equity")),
                      assets=by_tag.get("Assets"), gross_profit=gross,
                      net_income=by_tag.get("ProfitLoss"),
                      operating_cash_flow=by_tag.get("CashFlowsFromUsedInOperatingActivities"))
        if result["assets"] is not None and result["assets"] > 0:
            return result,scope
    return {}, ""


def filings(key, raw, corp, start, end):
    page = 1
    while True:
        path = raw / f"{corp}_{start}_{end}_annual_{page}.json"
        blob = cached(key, path, "list.json", corp_code=corp, bgn_de=start, end_de=end,
                      pblntf_detail_ty="A001", page_count=100, page_no=page)
        response = json.loads(blob)
        if response["status"] == "013":
            return
        if response["status"] != "000":
            raise RuntimeError(f"OpenDART list status={response['status']}")
        yield from response["list"]
        if page >= response["total_page"]:
            return
        page += 1


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--raw", type=Path, required=True)
    p.add_argument("--out", type=Path, required=True)
    p.add_argument("--start", default="20200101")
    p.add_argument("--end", default="20261126")
    p.add_argument("--symbol", action="append", required=True, help="Exact security to DART corporation mapping as 005930=00126380")
    a = p.parse_args()
    key = os.environ.get("OPENDART_API_KEY")
    if not key:
        p.error("set OPENDART_API_KEY")
    a.raw.mkdir(parents=True,exist_ok=True)
    a.out.mkdir(parents=True,exist_ok=True)
    rows, coverage = [], []
    counts = Counter()
    for pair in a.symbol:
        security, corp = pair.split("=", 1)
        if not re.fullmatch("[0-9]{6}", security) or not re.fullmatch("[0-9]{8}", corp):
            p.error("expected 6 digit security and 8 digit corporation code")
        for r in filings(key, a.raw, corp, a.start, a.end):
            acc, datecode = r["rcept_no"], r["rcept_dt"]
            found = re.search(r"사업보고서\s*\((\d{4})\.(\d{2})\)", r["report_nm"])
            if not found or not re.fullmatch(r"\d{14}", acc) or not re.fullmatch(r"\d{8}", datecode):
                counts["invalid_metadata"] += 1
                continue
            year,month = map(int,found.groups())
            end = dt.date(year,month,calendar.monthrange(year,month)[1]).isoformat()
            published=dt.datetime.strptime(datecode,"%Y%m%d").date().isoformat()
            if published <= end:
                counts["invalid_publication"] += 1
                continue
            try:
                blob = cached(key, a.raw / f"{acc}.zip", "fnlttXbrl.xml", rcept_no=acc, reprt_code="11011")
            except RuntimeError:
                counts["download_error"] += 1
                coverage.append(dict(issuer=security, corp_code=corp, published=published,
                                     accession=acc, fiscal_end=end, status="download_error",
                                     scope="", sha256=""))
                continue
            if not blob.startswith(b"PK"):
                status = re.search(rb"<status>([0-9]+)</status>",blob)
                code = status.group(1).decode() if status else "missing_zip"
                counts[f"xbrl_{code}"] += 1
                if code in {"010","011","012","020","021","901"}:
                    raise RuntimeError(f"OpenDART XBRL stopped, status={code}")
                coverage.append(dict(issuer=security, corp_code=corp, published=published,
                                     accession=acc, fiscal_end=end, status=code, scope="",
                                     sha256=hashlib.sha256(blob).hexdigest()))
                continue
            try:
                fact,scope = extract(blob,end)
            except (ET.ParseError, zipfile.BadZipFile, StopIteration, ValueError):
                fact,scope = {},""
            counts["extracted" if fact else "unsupported_xbrl"] += 1
            coverage.append(dict(issuer=security, corp_code=corp, published=published, accession=acc,
                                 fiscal_end=end, status="extracted" if fact else "unsupported_xbrl",
                                 scope=scope, sha256=hashlib.sha256(blob).hexdigest()))
            if fact:
                rows.append(dict(market="KR", issuer=security, fiscal_end=end, published=published, accession=acc, **fact))
    for label, data, fields in (
        ("kr_dart_finance.csv", rows, FIELDS),
        ("kr_dart_coverage.csv", coverage, ("issuer","corp_code","published","accession","fiscal_end","status","scope","sha256")),
    ):
        with (a.out/label).open("w",newline="") as file:
            w=csv.DictWriter(file,fields)
            w.writeheader()
            w.writerows(sorted(data,key=lambda r:(r["issuer"],r["published"],r["accession"])))
    print(json.dumps(counts))


if __name__ == "__main__":
    main()
