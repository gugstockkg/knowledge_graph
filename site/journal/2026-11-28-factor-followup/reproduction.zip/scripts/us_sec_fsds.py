#!/usr/bin/env python3
"""Collect as-filed annual US-GAAP disclosures from SEC FSDS quarter archives."""

import argparse
import csv
import hashlib
import io
import json
import os
from collections import Counter, defaultdict
from datetime import date, datetime, timedelta
from decimal import Decimal, InvalidOperation
from pathlib import Path
from shutil import copyfileobj
from time import sleep
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen
from zipfile import BadZipFile, ZipFile

BASE_URL = "https://www.sec.gov/files/dera/data/financial-statement-data-sets"
FORMS = frozenset(("10-K", "10-K/A", "10-KT", "10-KT/A"))
FIELDS = {
    "book_equity": ("StockholdersEquity", "StockholdersEquityIncludingPortionAttributableToNoncontrollingInterest"),
    "assets": ("Assets",),
    "gross_profit": ("GrossProfit",),
    "net_income": ("NetIncomeLoss", "ProfitLoss"),
    "operating_cash_flow": ("NetCashProvidedByUsedInOperatingActivities",),
}
REVENUE = ("RevenueFromContractWithCustomerExcludingAssessedTax", "SalesRevenueNet", "Revenues")
COST = ("CostOfRevenue", "CostOfGoodsAndServicesSold", "CostOfGoodsSold")
STOCK_TAGS = {t for field in ("assets", "book_equity") for t in FIELDS[field]}
TAGS = {t for field_tags in FIELDS.values() for t in field_tags} | set(REVENUE) | set(COST)
HEAD = ("market", "issuer", "fiscal_end", "published", "accession", *FIELDS,
        "accepted_source", "filed", "form", "source_quarter", "source_url")


def fiscal_quarters(start, end):
    def parse(q):
        year, quarter = q.lower().split("q")
        if len(year) != 4 or quarter not in ("1", "2", "3", "4") or not year.isdigit():
            raise ValueError(f"invalid quarter: {q}")
        return int(year) * 4 + int(quarter) - 1

    start_value, end_value = parse(start), parse(end)
    if start_value > end_value:
        raise ValueError("start quarter must not follow end quarter")
    for value in range(start_value, end_value + 1):
        year, quarter = divmod(value, 4)
        yield f"{year}q{quarter + 1}"


def acquire(path, quarter, agent):
    url = f"{BASE_URL}/{quarter}.zip"
    part = path.with_suffix(".zip.part")
    for attempt in range(3):
        try:
            request = Request(url, headers={"User-Agent": agent, "Accept": "application/zip"})
            with urlopen(request, timeout=120) as response, part.open("wb") as output:
                copyfileobj(response, output)
            with ZipFile(part) as archive:
                for name in ("sub.txt", "num.txt"):
                    archive.getinfo(name)
            part.replace(path)
            sleep(1)
            return
        except (HTTPError, URLError, TimeoutError, BadZipFile, KeyError) as exc:
            part.unlink(missing_ok=True)
            if isinstance(exc, HTTPError) and exc.code not in (429, 500, 502, 503, 504):
                raise
            if attempt == 2:
                raise
            retry = exc.headers.get("Retry-After", "") if isinstance(exc, HTTPError) else ""
            sleep(min(120, int(retry)) if retry.isdecimal() else 5 * (attempt + 1))


def parse_day(raw):
    return datetime.strptime(raw, "%Y%m%d").date()


def available_date(accepted, filed):
    if not accepted:
        return None
    try:
        format_string = "%Y-%m-%d %H:%M:%S.%f" if "." in accepted else "%Y-%m-%d %H:%M:%S"
        accepted_day = datetime.strptime(accepted, format_string).date()
        return max(accepted_day, parse_day(filed)) + timedelta(days=1)
    except ValueError:
        return None


def source_digest(path):
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def annual_rows(path, quarter, cutoff):
    diagnostics = Counter()
    with ZipFile(path) as archive:
        with archive.open("sub.txt") as member:
            filings = {}
            for raw in csv.DictReader(io.TextIOWrapper(member, encoding="utf-8-sig"), delimiter="\t"):
                if raw["form"] not in FORMS:
                    continue
                seen = available_date(raw["accepted"], raw["filed"])
                if seen is None:
                    diagnostics["missing_or_invalid_availability"] += 1
                    continue
                if seen > cutoff:
                    diagnostics["after_cutoff"] += 1
                    continue
                if not raw["period"] or not raw["cik"].isdigit():
                    diagnostics["missing_identity_or_period"] += 1
                    continue
                fiscal_end = parse_day(raw["period"])
                if fiscal_end >= seen:
                    diagnostics["invalid_fiscal_end"] += 1
                    continue
                filings[raw["adsh"]] = {
                    "market": "US",
                    "issuer": raw["cik"].zfill(10),
                    "fiscal_end": fiscal_end.isoformat(),
                    "published": seen.isoformat(),
                    "accession": raw["adsh"],
                    "accepted_source": raw["accepted"],
                    "filed": parse_day(raw["filed"]).isoformat(),
                    "form": raw["form"],
                    "source_quarter": quarter,
                    "source_url": "https://www.sec.gov/Archives/edgar/data/"
                                  f"{int(raw['cik'])}/{raw['adsh'].replace('-', '')}/",
                    "period_source": raw["period"],
                }

        observations = defaultdict(lambda: defaultdict(set))
        with archive.open("num.txt") as member:
            headers = member.readline().decode("utf-8-sig").rstrip("\r\n").split("\t")
            columns = {name: headers.index(name) for name in
                       ("adsh", "tag", "version", "ddate", "qtrs", "uom", "coreg", "value")}
            segments_column = headers.index("segments") if "segments" in headers else None
            for line in member:
                accession = line.split(b"\t", 1)[0].decode("ascii")
                filing = filings.get(accession)
                if filing is None:
                    continue
                values = line.decode("utf-8").rstrip("\r\n").split("\t")
                tag = values[columns["tag"]]
                if tag not in TAGS or values[columns["uom"]] != "USD":
                    continue
                if not values[columns["version"]].startswith("us-gaap/"):
                    continue
                if values[columns["ddate"]] != filing["period_source"]:
                    continue
                if values[columns["qtrs"]] != ("0" if tag in STOCK_TAGS else "4"):
                    continue
                if values[columns["coreg"]] or (segments_column is not None and values[segments_column]):
                    continue
                try:
                    number = Decimal(values[columns["value"]])
                except InvalidOperation:
                    diagnostics["invalid_numeric_values"] += 1
                    continue
                if number.is_finite():
                    observations[accession][tag].add(number)

        def pick(facts, aliases):
            for tag in aliases:
                values = facts.get(tag, ())
                if len(values) == 1:
                    return next(iter(values)), tag
                if len(values) > 1:
                    diagnostics["conflicting_standard_tags"] += 1
                    return None, ""
            return None, ""

        result = []
        for accession, filing in filings.items():
            facts = observations[accession]
            selected = {field: pick(facts, aliases) for field, aliases in FIELDS.items()}
            if selected["gross_profit"][0] is None and not facts.get("GrossProfit"):
                revenue, revenue_tag = pick(facts, REVENUE)
                cost, cost_tag = pick(facts, COST)
                if revenue is not None and cost is not None and revenue >= 0 and cost >= 0:
                    selected["gross_profit"] = (revenue - cost, f"{revenue_tag}-{cost_tag}")
            if not any(number is not None for number, _ in selected.values()):
                diagnostics["filings_without_eligible_facts"] += 1
                continue
            result.append((filing, selected))
        diagnostics["filings_retained"] = len(result)
        for field in FIELDS:
            diagnostics[f"{field}_reported"] = sum(s[field][0] is not None for _, s in result)
        return result, diagnostics


def write_rows(records, output_dir):
    versions = defaultdict(dict)
    accepted_accessions = set()
    out = output_dir / "finance_us.csv"
    evidence = output_dir / "finance_us_evidence.csv"
    fd_tmp = out.with_suffix(".csv.part")
    ev_tmp = evidence.with_suffix(".csv.part")
    rows = 0
    with fd_tmp.open("w", newline="") as csv_file, ev_tmp.open("w", newline="") as ev_file:
        writer = csv.DictWriter(csv_file, fieldnames=HEAD, extrasaction="ignore")
        evidence_writer = csv.writer(ev_file)
        writer.writeheader()
        evidence_writer.writerow(("issuer", "fiscal_end", "published", "row_accession",
                                  "metric", "value", "tag_or_formula", "fact_accession"))
        for filing, selected in sorted(records, key=lambda item: (
                item[0]["published"], item[0]["accepted_source"], item[0]["accession"])):
            accession = filing["accession"]
            if accession in accepted_accessions:
                continue
            accepted_accessions.add(accession)
            current = versions[filing["issuer"], filing["fiscal_end"]]
            for metric, (number, tag) in selected.items():
                if number is not None:
                    current[metric] = (number, tag, accession)
            writer.writerow({**filing, **{k: v[0] for k, v in current.items()}})
            for metric, (number, tag, source) in current.items():
                evidence_writer.writerow((filing["issuer"], filing["fiscal_end"], filing["published"],
                                          accession, metric, number, tag, source))
            rows += 1
    ev_tmp.replace(evidence)
    fd_tmp.replace(out)
    return rows, len({key[0] for key in versions})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raw", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--from-quarter", default="2020q1")
    parser.add_argument("--to-quarter", default="2026q3")
    parser.add_argument("--cutoff", type=date.fromisoformat, default=date(2026, 11, 26))
    parser.add_argument("--user-agent", default=os.environ.get("SEC_USER_AGENT"))
    parser.add_argument("--allow-missing", action="store_true")
    parser.add_argument("--offline", action="store_true")
    args = parser.parse_args()
    args.raw.mkdir(parents=True, exist_ok=True)
    args.out.mkdir(parents=True, exist_ok=True)
    manifest = {"expected_quarters": list(fiscal_quarters(args.from_quarter, args.to_quarter)),
                "cutoff": args.cutoff.isoformat(),
                "availability_rule": "calendar day after later of EDGAR accepted date and filed date",
                "source_family": "SEC FSDS consolidated US-GAAP annual facts"}
    records, quarters, missing = [], [], []
    for quarter in manifest["expected_quarters"]:
        path = args.raw / f"{quarter}.zip"
        if not path.is_file():
            if args.offline:
                missing.append(quarter)
                continue
            if not args.user_agent:
                parser.error("SEC_USER_AGENT or --user-agent must identify your organization and contact")
            try:
                acquire(path, quarter, args.user_agent)
            except (HTTPError, URLError, TimeoutError, BadZipFile, KeyError) as exc:
                print(f"{quarter}: download unavailable: {exc}", flush=True)
                missing.append(quarter)
                continue
        filings, diagnostics = annual_rows(path, quarter, args.cutoff)
        records.extend(filings)
        quarters.append({"quarter": quarter, "sha256": source_digest(path), "bytes": path.stat().st_size,
                         "available_financials": dict(diagnostics)})
        print(f"{quarter}: {len(filings)} annual disclosures", flush=True)
    manifest.update(quarters=quarters, missing_quarters=missing)
    if missing and not args.allow_missing:
        parser.error(f"missing quarter archives: {', '.join(missing)}; use --allow-missing only for a diagnostic panel")
    if not records:
        parser.error("no eligible annual filings")
    rows, issuers = write_rows(records, args.out)
    manifest.update(rows=rows, issuers=issuers)
    (args.out / "finance_us_manifest.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"rows": rows, "issuers": issuers, "missing_quarters": missing}), flush=True)


if __name__ == "__main__":
    main()
