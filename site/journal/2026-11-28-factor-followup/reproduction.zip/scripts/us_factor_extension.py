"""EC2 US historical SPY constituent subset with as-filed annual factors."""

import argparse
import hashlib
import json
import math
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from statistics import median
from urllib.parse import quote
from urllib.request import Request, urlopen
from zipfile import ZipFile
from zoneinfo import ZoneInfo

from run_factor_backtest import FACTORS, dump, number, read, simulate


def months_between(start, end):
    year, month = map(int, start.split('-'))
    while (value := f'{year:04d}-{month:02d}') <= end:
        yield value
        month += 1
        if month == 13:
            year, month = year + 1, 1


def original_shares(raw, filings):
    """Shares from the balance-sheet date and filing accession, with no later corrections."""
    dates = {
        r['accession']: (r['source_quarter'], r['fiscal_end'].replace('-', ''))
        for r in filings
    }
    shares = defaultdict(set)
    for quarter in sorted({v[0] for v in dates.values()}):
        with ZipFile(raw / f'{quarter}.zip') as archive, archive.open('num.txt') as nums:
            headers = nums.readline().decode('utf-8-sig').strip().split('\t')
            at = {name: headers.index(name) for name in
                  ('tag', 'ddate', 'qtrs', 'uom', 'coreg', 'version', 'value')}
            segment = headers.index('segments') if 'segments' in headers else None
            prefix = b'\tCommonStockSharesOutstanding\t'
            for line in nums:
                if prefix not in line:
                    continue
                cells = line.decode('utf-8').rstrip('\r\n').split('\t')
                accession = cells[0]
                if dates.get(accession) != (quarter, cells[at['ddate']]):
                    continue
                if (cells[at['tag']] != 'CommonStockSharesOutstanding' or
                    cells[at['uom']].lower() != 'shares' or cells[at['qtrs']] != '0' or
                    cells[at['coreg']] or (segment is not None and cells[segment]) or
                    not cells[at['version']].startswith('us-gaap/')):
                    continue
                count = number(cells[at['value']])
                if count is not None and count > 0:
                    shares[accession].add(count)
    return {k: next(iter(v)) for k, v in shares.items() if len(v) == 1}


def chart(path, ticker):
    market = json.loads(path.read_bytes())['chart']['result'][0]
    meta = market['meta']
    if meta['dataGranularity'] != '1mo' or meta['symbol'] != ticker or meta['currency'] != 'USD':
        raise ValueError(f'invalid archive metadata: {ticker}')
    zone = ZoneInfo(meta['exchangeTimezoneName'])
    date = lambda stamp: datetime.fromtimestamp(stamp, zone).date().isoformat()
    prices = market['indicators']['quote'][0]['close']
    adj = market['indicators']['adjclose'][0]['adjclose']
    months = {}
    for stamp, close, adjusted in zip(market['timestamp'], prices, adj):
        month = date(stamp)[:7]
        if close and adjusted and min(close, adjusted) > 0:
            if month in months:
                raise ValueError(f'duplicate monthly bar: {ticker} {month}')
            months[month] = close, adjusted
    splits = sorted((date(row['date']), row['numerator']/row['denominator'])
                    for row in market.get('events', {}).get('splits', {}).values())
    return months, splits


def split_archive(ticker, root):
    path = root / f'{ticker}.json'
    if not path.exists():
        start = int(datetime(2018, 1, 1, tzinfo=timezone.utc).timestamp())
        end = int(datetime(2026, 11, 27, tzinfo=timezone.utc).timestamp())
        for host in (1, 2):
            url = (f'https://query{host}.finance.yahoo.com/v8/finance/chart/{quote(ticker)}'
                   f'?period1={start}&period2={end}&interval=1mo&events=div%2Csplits')
            try:
                with urlopen(Request(url, headers={'User-Agent': 'Mozilla/5.0'}), timeout=18) as stream:
                    content = stream.read()
                payload = json.loads(content)['chart']['result'][0]
                if (payload['meta']['symbol'] == ticker and
                    payload['meta']['dataGranularity'] == '1mo' and 'indicators' in payload):
                    path.write_bytes(content)
                    break
            except (OSError, ValueError, KeyError, TypeError, IndexError):
                continue
    return ticker, path if path.exists() else None


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--archive', type=Path, required=True)
    p.add_argument('--sec', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--splits-cache', type=Path, required=True)
    p.add_argument('--fetch-splits', action='store_true')
    p.add_argument('--start', default='2021-11')
    p.add_argument('--end', default='2026-10')
    args = p.parse_args()
    dates = list(months_between('2020-10', args.end))
    p_map = {d: i for i, d in enumerate(dates)}
    holdings = args.archive / 'constituents.csv'
    index = [row for row in read(holdings) if row['market'] == 'US' and
             row['known'][:7] < args.start]
    snapshot = max(row['snapshot'] for row in index)
    index = [row for row in index if row['snapshot'] == snapshot]
    ticker_map = args.archive / 'identity/company_tickers.json'
    ciks = defaultdict(set)
    for row in json.loads(ticker_map.read_bytes()).values():
        ciks[row['ticker']].add(str(row['cik_str']).zfill(10))
    matching = {row['ticker']: next(iter(ciks[row['ticker']])) for row in index
                if len(ciks[row['ticker']]) == 1}
    multiple = Counter(matching.values())
    stats = Counter()
    candidates = sorted(t for t,c in matching.items() if multiple[c] == 1
                        and (args.archive / 'prices' / f'{t}.json').is_file())
    if args.fetch_splits:
        args.splits_cache.mkdir(parents=True, exist_ok=True)
        with ThreadPoolExecutor(max_workers=8) as pool:
            list(pool.map(lambda ticker: split_archive(ticker,args.splits_cache),candidates))
    panel = {}
    manifest = []
    for ticker, cik in sorted(matching.items()):
        path = args.archive / 'prices' / f'{ticker}.json'
        if multiple[cik] != 1:
            stats['multiple_snapshot_tickers_for_cik'] += 1
            continue
        if not path.is_file():
            stats['missing_price_archive'] += 1
            continue
        prices, _ = chart(path, ticker)
        events_path = args.splits_cache / path.name
        if not events_path.is_file():
            stats['missing_requested_split_archive'] += 1
            continue
        event_prices, splits = chart(events_path, ticker)
        if args.end not in prices or args.end not in event_prices or not math.isclose(
            prices[args.end][0], event_prices[args.end][0], rel_tol=.001):
            stats['incompatible_split_units'] += 1
            continue
        if any(d not in prices for d in dates):
            stats['missing_evaluation_or_warmup_months'] += 1
            continue
        panel[ticker] = (cik, prices, splits)
        manifest.append(dict(ticker=ticker,cik=cik,snapshot=snapshot,
                             price_name=path.name,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                             splits_sha256=hashlib.sha256(events_path.read_bytes()).hexdigest()))
    if len(panel) < 20:
        raise ValueError(f'insufficient archive coverage: {len(panel)}')
    finance = args.sec / 'outputs/finance_us.csv'
    filings = [r for r in read(finance) if r['issuer'] in {item[0] for item in panel.values()}]
    shares = original_shares(args.sec / 'raw', filings)
    by_issuer = defaultdict(list)
    for row in filings:
        by_issuer[row['issuer']].append(row)
    output = args.out
    output.mkdir(parents=True, exist_ok=True)
    (output / 'us_factor_coverage.json').write_text(json.dumps(dict(
        requested_start=args.start,requested_end=args.end,snapshot=snapshot,
        snapshot_known=sorted({r['known'] for r in index}), snapshot_rows=len(index),
        mapped_single_ticker=len(matching),complete_prices=len(panel),
        filtered=dict(stats),available_filing_rows=len(filings),share_facts=len(shares),
        finance_sha256=hashlib.sha256(finance.read_bytes()).hexdigest(),
        holdings_sha256=hashlib.sha256(holdings.read_bytes()).hexdigest(),
        ticker_map_sha256=hashlib.sha256(ticker_map.read_bytes()).hexdigest()),indent=2)+'\n')
    dump(output / 'us_factor_universe.csv', manifest)

    returns, targets, signals, coverage = defaultdict(dict), {}, [], []
    for i, month in enumerate(dates):
        if i:
            for ticker, (_, price, _) in panel.items():
                returns[month]['US', ticker] = dict(
                    krw=price[month][1]/price[dates[i-1]][1]-1, terminal=False)
        if month < args.start:
            continue
        signal_month = dates[i-1]
        scores = {}
        for ticker, (cik, price, splits) in panel.items():
            versions = [r for r in by_issuer[cik] if r['published'][:7] < signal_month]
            row = max(versions,key=lambda r:(r['fiscal_end'],r['published'],r['accession']),default={})
            equity, assets, gross, income, cash = (number(row.get(k)) for k in
                ('book_equity','assets','gross_profit','net_income','operating_cash_flow'))
            candidates = [r for r in versions if r['fiscal_end'] == row['fiscal_end']
                          and r['accession'] in shares]
            share_row = max(candidates,key=lambda r:(r['published'],r['accession']),default={})
            share_count = shares.get(share_row.get('accession'))
            # Convert historical reported shares to the archive's split-normalized quote units.
            cap = (share_count * price[signal_month][0] * math.prod(
                ratio for day, ratio in splits if day > share_row['fiscal_end'])
                if share_count else None)
            data = (equity/cap if cap and equity and equity > 0 else None,
                    gross/assets if gross is not None and assets and assets > 0 else None,
                    (cash-income)/assets if cash is not None and income is not None and assets and assets > 0 else None,
                    price[dates[i-2]][1]/price[dates[i-13]][1]-1)
            if all(x is not None for x in data):
                scores[ticker] = data, row, share_row, cap
        if len(scores) < 20:
            raise ValueError(f'insufficient complete scores: {month} {len(scores)}')
        coverage.append(dict(trade_month=month,signal_month=signal_month,all_factor_scores=len(scores)))
        target = targets[month] = {}
        equal = {('US', t): 1/len(scores) for t in scores}
        target['hold'] = target['equal_rebalance'] = equal
        n = math.ceil(.3*len(scores))
        for j,factor in enumerate(FACTORS):
            selected = sorted(scores,key=lambda t:(-scores[t][0][j],t))[:n]
            target[factor] = {('US', t): 1/n for t in selected}
            for ticker in selected:
                values, row, share_row, cap = scores[ticker]
                signals.append(dict(trade_month=month, signal_month=signal_month,
                    factor=factor,ticker=ticker,cik=panel[ticker][0],score=values[j],
                    filing=row['accession'] if j != 3 else '',
                    published=row['published'] if j != 3 else '',
                    shares_filing=share_row['accession'] if j == 0 else '',
                    market_cap_estimate=cap if j == 0 else ''))
    cohorts, orders = [], []
    for horizon in (12,24):
        for month in targets:
            i = p_map[month]
            if i+horizon >= len(dates):
                continue
            paired = [simulate(s,i,horizon,returns,dates,targets,.001,orders)
                      for s in ('hold','equal_rebalance',*FACTORS)]
            for row in paired:
                row['paired_vs_hold'] = row['net'] - paired[0]['net']
                row['paired_vs_equal_rebalance'] = row['net'] - paired[1]['net']
            cohorts.extend(paired)
    summary = []
    for horizon in (12,24):
        for strategy in ('hold','equal_rebalance',*FACTORS):
            group = [r for r in cohorts if r['strategy']==strategy and r['months']==horizon]
            summary.append(dict(months=horizon,strategy=strategy,accounts=len(group),
                median_net=median(row['net'] for row in group),
                median_drawdown=median(row['monthly_drawdown'] for row in group),
                median_vs_hold=median(row['paired_vs_hold'] for row in group),
                median_vs_equal_rebalance=median(row['paired_vs_equal_rebalance'] for row in group),
                wins_vs_hold=sum(row['paired_vs_hold']>0 for row in group),
                target_hits=sum(row['target'] for row in group)))
    dump(output / 'us_factor_monthly_coverage.csv',coverage)
    dump(output / 'us_factor_summary.csv',summary)
    dump(output / 'us_factor_cohorts.csv',cohorts)
    dump(output / 'us_factor_selections.csv',signals)
    dump(output / 'us_factor_orders.csv',orders)


if __name__ == '__main__':
    main()
