"""Evaluate published AQR long-short factors and a same-source US total-market benchmark."""
import argparse
import datetime as dt
import hashlib
import re
import statistics
import zipfile
from pathlib import Path
from urllib.request import Request, urlopen
from xml.etree import ElementTree as ET

from run_public_factor_followup import export, metric

BASE = 'https://www.aqr.com/-/media/AQR/Documents/Insights/Data-Sets/'
FILES = {'bab': 'Betting-Against-Beta-Equity-Factors-Monthly.xlsx',
         'qmj': 'Quality-Minus-Junk-Factors-Monthly.xlsx'}


def read_series(workbook, sheet, label):
    with zipfile.ZipFile(workbook) as z:
        sheets = ET.fromstring(z.read('xl/workbook.xml')).findall('.//{*}sheet')
        entry = next(x for x in sheets if x.get('name') == sheet)
        rid = entry.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id')
        rels = ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
        target = next(x.get('Target') for x in rels if x.get('Id') == rid)
        shared = [''.join(x.itertext()) for x in ET.fromstring(z.read('xl/sharedStrings.xml'))]
        rows = ET.fromstring(z.read('xl/' + target)).findall('.//{*}row')
    output = {}
    date_col, value_col = None, None
    for row in rows:
        values = {}
        for c in row:
            v = c.find('{*}v')
            if v is None or v.text is None or c.get('t') == 'e':
                continue
            col = re.match(r'[A-Z]+', c.get('r'))[0]
            values[col] = shared[int(v.text)] if c.get('t') == 's' else v.text
        if date_col is None and 'DATE' in values.values() and label in values.values():
            date_col = next(k for k, v in values.items() if v == 'DATE')
            value_col = next(k for k, v in values.items() if v == label)
        elif date_col in values and value_col in values:
            raw_day = values[date_col]
            if raw_day.isdigit():
                day = dt.date(1899, 12, 30) + dt.timedelta(days=int(raw_day))
            else:
                try:
                    day = dt.datetime.strptime(raw_day, '%m/%d/%Y').date()
                except ValueError:
                    continue
            month = day.strftime('%Y%m')
            if month in output:
                raise ValueError(f'duplicate {sheet} {label} {month}')
            output[month] = float(values[value_col])
    if not output:
        raise ValueError(f'missing monthly observations: {sheet} {label}')
    return output


def run(out, first, last):
    raw = out / 'raw'
    raw.mkdir(parents=True, exist_ok=True)
    paths = {}
    for key, name in FILES.items():
        path = raw / name
        if not path.exists():
            with urlopen(Request(BASE + name, headers={'User-Agent': 'FINTOS research'}), timeout=30) as r:
                body = r.read()
            path.write_bytes(body)
        paths[key] = path
    rows, manifest = {}, []
    for key, file, sheet, col in (
        ('bab', 'bab', 'BAB Factors', 'USA'), ('qmj', 'qmj', 'QMJ Factors', 'USA'),
        ('hml_ff', 'qmj', 'HML FF', 'USA'), ('hml_devil', 'qmj', 'HML Devil', 'USA'),
        ('mkt', 'qmj', 'MKT', 'USA'), ('rf', 'qmj', 'RF', 'Risk Free Rate'),
    ):
        path = paths[file]
        rows[key] = read_series(path, sheet, col)
        manifest.append(dict(dataset=key, source=BASE + path.name, sheet=sheet, column=col,
                             sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                             first=min(rows[key]), last=max(rows[key])))
    common = sorted(m for m in set.intersection(*(set(x) for x in rows.values())) if first <= m <= last)
    idx = lambda m: int(m[:4])*12 + int(m[-2:])
    if len(common) < 24 or any(idx(a)+1 != idx(b) for a,b in zip(common,common[1:])):
        raise ValueError('Insufficient contiguous common period')
    results = []
    for horizon in (12, 24):
        windows = [common[i:i+horizon] for i in range(len(common)-horizon+1)]
        measure = {k: [metric(rows[k][m] + rows['rf'][m] for m in w) for w in windows]
                   for k in ('mkt', 'bab', 'qmj', 'hml_ff', 'hml_devil')}
        for key, values in measure.items():
            rr, mdd = zip(*values)
            market = [r - m[0] for r, m in zip(rr, measure['mkt'])]
            hml = [r - m[0] for r, m in zip(rr, measure['hml_ff'])]
            results.append(dict(strategy=key, months=horizon, first=common[0], last=common[-1],
                                accounts=len(windows), median_total=statistics.median(rr),
                                median_mdd=statistics.median(mdd), paired_vs_market=statistics.median(market),
                                wins_vs_market=sum(d>1e-10 for d in market),
                                paired_vs_hml_ff=statistics.median(hml)))
    export(out, 'aqr_factor_manifest', manifest)
    export(out, 'aqr_factor_summary', results)


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--start', default='202112')
    p.add_argument('--end', default='202610')
    a = p.parse_args()
    run(a.out, a.start, a.end)
