# 미국 시점별 재무와 상장 이력

## 1. 공식 재무 자료

SEC Financial Statement Data Sets의 분기별 ZIP에서 SUB의 제출 이력과 NUM의 수치를 접수번호 `adsh`로 연결한다. 2020년 1분기 이후를 받아 주평가 시작일 전의 연간 재무를 준비한다. 원본 ZIP과 SHA-256, 분기별 누락 여부를 수집 장부에 남긴다. [SEC 자료 안내](https://www.sec.gov/data-research/sec-markets-data/financial-statement-data-sets) · [파일 정의서](https://www.sec.gov/dera/data/fsds.pdf)

```bash
export SEC_USER_AGENT='기관명 담당자 연락처'
python3 scripts/us_sec_fsds.py \
  --raw /var/lib/fintos-portfolio/2026-11-28/us-pit/raw \
  --out /var/lib/fintos-portfolio/2026-11-28/us-pit/outputs \
  --from-quarter 2020q1 --to-quarter 2026q3 --cutoff 2026-11-26
```

보관본만 사용할 때는 `--offline`을 지정한다. 기본 실행은 요청한 분기 파일이 빠지면 실패한다. `--allow-missing`은 진단으로 사용할 때 명시적으로 켠다. EC2에서 2020년 1분기~2026년 3분기의 27개 ZIP(약 2.6GB)을 확보했다. 2026년 4분기 SEC 분기 아카이브가 포함되지 않으므로 2026년 10~11월 신규 제출은 다른 수집 경로로 보강해야 한다.

| 항목 | 채택 기준 |
|---|---|
| 기업과 보고 시점 | 10자리 CIK, 원문 접수번호, SUB 보고기간, 접수 시각 원문 |
| 전략 관측 가능일 | EDGAR 접수일과 제출일 중 늦은 날짜의 다음 달력일. 장중 접수를 같은 날 신호에 사용하지 않는 보수적 가정이다. |
| 보고 유형 | 10-K, 10-K/A, 10-KT, 10-KT/A의 연결 연간 US-GAAP 표준 태그와 USD 수치 |
| 재무상태 | SUB 보고기간과 NUM 종료일이 같은 장부자본·총자산, `qtrs=0` |
| 손익·현금흐름 | 보고기간 종료일이 같은 매출총이익·당기순이익·영업현금흐름, `qtrs=4`. 보고된 매출총이익이 없으면 같은 보고서의 매출과 매출원가 태그를 사용한다. |
| 개정 | 동일 기업·회계기간에서 그때까지 확인된 값만 유지한다. 필드별 최초 또는 개정 접수번호는 근거 CSV에 기록한다. |
| 미관측 | 연결재무, 표준 태그 또는 보고기간이 일치하지 않으면 빈 값으로 남긴다. |

`finance_us.csv`의 공통 필드는 `market,issuer,fiscal_end,published,accession,book_equity,assets,gross_profit,net_income,operating_cash_flow`다. 원문 접수 시각, 제출일, 양식, 분기, 원문 URL도 포함한다. `finance_us_evidence.csv`는 그 행의 각 값에 실제 수치를 제출한 접수번호와 태그를 연결한다. `finance_us_manifest.json`은 원본과 표준화 정합성 점검 결과다. CIK는 회사 식별자이므로 보통주와 여러 주식 클래스의 이력을 구분할 수 있는 증권 식별자가 추가로 필요하다.

EC2의 연간 재무 추출 결과는 고유 접수번호 42,685건, CIK 8,782개였다. 날짜 검증에서 전 행의 관측 가능일이 접수일·제출일·회계기간 종료일보다 늦었다. 값이 있는 행은 장부자본 41,403건, 자산 42,281건, 매출총이익 19,489건, 당기순이익 41,200건, 영업현금흐름 40,479건이었다. 애플의 2022년 연간 보고서는 10월 27일 18시 1분에 접수됐고 제출일은 10월 28일로 기록되어 관측 가능일을 10월 29일로 두었다.

## 2. 상장·상폐 공시 감사

SEC 분기별 EDGAR master index에서 거래소 등록 양식 `8-A12B` 및 상장 제거 통지 `25`, `25-NSE`와 그 개정을 별도로 추출한다. [EDGAR 개발자 자료](https://www.sec.gov/about/developer-resources) · [SEC Form 25](https://www.sec.gov/files/form25.pdf)

```bash
python3 scripts/us_exchange_notice_audit.py \
  --raw /var/lib/fintos-portfolio/2026-11-28/us-pit/master \
  --out /var/lib/fintos-portfolio/2026-11-28/us-pit/outputs \
  --from-quarter 2021q4 --to-quarter 2026q4 --start 2021-11-26 --end 2026-11-26
```

`us_exchange_notices.csv`는 양식이 공개된 날짜와 원문을 찾는 장부다. 주식 클래스의 변경·이전 상장에도 양식이 제출될 수 있고 공시일, 효력일, 마지막 거래일은 별도로 확인해야 한다. 이 장부에는 당시 거래 가능한 전체 증권 수나 보유자의 현금·주식 수령액이 없다. 21개 분기의 원본에서 총 18,096행을 확인했다. 최초 상장 제거 통지 10,300행(색인 CIK 3,635개)과 개정 통지 118행이 포함되며, 이 수치는 상장폐지된 보통주 종목 수와 다르다.

## 3. 전수 시점별 종목군의 요건

백테스트 입력에는 날짜별 상장 모집단과 증권 ID, 거래 가능 여부, 기업 ID, 시가총액, 기업행동을 반영한 수익률, 상장폐지 청산 수익률이 필요하다. 현재 종목 목록으로 과거 수익률을 붙이면 상장폐지 종목과 종목 코드 변경이 누락된다. SEC 공시 장부를 더해도 거래소 시계열과 최종 회수액의 결측은 해결되지 않는다.

- Nasdaq Data Link의 Sharadar SEP는 활성·상장폐지 시세를 제공한다. 공개 무료 표본은 일부 종목과 특정 기간에 한정된다. 증권 분류, 기업행동 및 상장폐지 말기의 수익 처리 방식은 파일 계약과 문서를 확인해야 한다. [Sharadar SEP 공식 문서](https://data.nasdaq.com/databases/SEP/documentation)
- Alpha Vantage Listing Status는 날짜를 지정한 상장 상태 조회를 안내한다. EC2에서 공식 예시 날짜의 데모 CSV는 확인했으나 2022년 표본은 데모 응답에 포함되지 않았다. 필요한 날짜의 종목 명단을 받아도 가격 및 상장폐지 수익률은 따로 확보해야 한다. [Alpha Vantage 공식 문서](https://www.alphavantage.co/documentation/#listing-status)
- CRSP 미국 주식 데이터는 역사적 증권·기업 식별자, 상장폐지 수익과 취득대가가 포함된 청산 정보를 명시한다. 현재 EC2 작업 환경에서는 해당 라이선스 데이터나 인증을 확인하지 못했다. [CRSP 공식 데이터 정의](https://www.crsp.org/crsp_pdf/crsp-us-stock-indexes-databases-data-descriptions-guide-crspaccess/)
- 재무가 확보됐더라도 증권별 가격과 상장폐지 회수가 확인된 범위까지만 시장성과를 보고한다. 부족한 최종 수익률을 0으로 채우거나 마지막 종가에서 소급 청산하지 않는다.
